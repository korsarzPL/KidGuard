import customtkinter as ctk
import json
import os
import base64
import security
import datetime
import calendar
from i18n import i18n

TAB_KEY = "tab_limits"
limits_vars = {}
cal_vars = {
    "year": datetime.date.today().year,
    "month": datetime.date.today().month
}

PLIK_LIMITOW = "limit_stan.json"
PLIK_KALENDARZA = "calendar_overrides.json"

class LimitDialog(ctk.CTkToplevel):
    def __init__(self, parent_widget, date_str, current_val, callback):
        super().__init__()
        self.title("Ustaw Czas")
        
        w, h = 320, 180
        ws = self.winfo_screenwidth()
        hs = self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(ws-w)//2}+{(hs-h)//2}")
        
        self.transient(parent_widget.winfo_toplevel())
        self.attributes("-topmost", True)
        self.lift()
        self.focus_force()
        self.callback = callback
        
        ctk.CTkLabel(self, text=f"Data: {date_str}", font=("Roboto", 14, "bold")).pack(pady=(20, 10))
        
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack()
        
        self.entry = ctk.CTkEntry(row, width=80, font=("Roboto Mono", 16, "bold"), justify="center")
        self.entry.insert(0, str(current_val))
        self.entry.pack(side="left")
        ctk.CTkLabel(row, text=i18n.get('min_label'), font=("Roboto", 12)).pack(side="left", padx=5)
        
        btn_f = ctk.CTkFrame(self, fg_color="transparent")
        btn_f.pack(pady=20)
        ctk.CTkButton(btn_f, text=i18n.get("limits_btn_set"), command=self.save, fg_color="#27ae60", hover_color="#219653", width=100).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text=i18n.get("btn_cancel"), command=self.destroy, fg_color="#95a5a6", hover_color="#7f8c8d", width=100).pack(side="right", padx=5)
        
        self.bind("<Return>", lambda e: self.save())
        self.entry.focus_set()
        
    def save(self):
        val = self.entry.get()
        if val.isdigit():
            self.callback(int(val))
            self.destroy()

def create_page(parent):
    container = ctk.CTkScrollableFrame(parent, fg_color="transparent")
    container.pack(fill="both", expand=True)

    limits_card = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    limits_card.pack(fill="x", pady=(0, 15), ipady=10)
    
    ctk.CTkLabel(limits_card, text=i18n.get("std_limits_title"), font=("Roboto", 16, "bold")).pack(anchor="w", padx=20, pady=(15, 10))

    std_limits = load_std_limits()
    days = [i18n.get(f"day_{i}") for i in range(7)]
    
    for i, day_name in enumerate(days):
        row = ctk.CTkFrame(limits_card, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(row, text=day_name, font=("Roboto", 12), width=100, anchor="w").pack(side="left")
        
        val_var = ctk.IntVar(value=int(std_limits.get(f"day_{i}", 60)))
        limits_vars[f"day_{i}"] = val_var
        val_lbl = ctk.CTkLabel(row, text=f"{val_var.get()} {i18n.get('min_label')}", font=("Roboto Mono", 12, "bold"), width=70)
        val_lbl.pack(side="right")
        
        slider = ctk.CTkSlider(row, from_=0, to=480, number_of_steps=480, variable=val_var, 
                              command=lambda v, l=val_lbl: l.configure(text=f"{int(v)} {i18n.get('min_label')}"),
                              progress_color="#1f6aa5", button_color="#1f6aa5", height=14)
        slider.pack(side="right", fill="x", expand=True, padx=15)

    cal_card = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    cal_card.pack(fill="x", pady=10, ipady=10)
    
    ctk.CTkLabel(cal_card, text=i18n.get("cal_limits_title"), font=("Roboto", 16, "bold")).pack(anchor="w", padx=20, pady=(10, 5))
    ctk.CTkLabel(cal_card, text="LPM - Ustaw własny czas (0 = blokada) | PPM - Usuń własny limit", font=("Roboto", 11), text_color="gray").pack(anchor="w", padx=20, pady=(0, 10))

    cal_container = ctk.CTkFrame(cal_card, fg_color=["#f9f9f9", "#202020"], corner_radius=10)
    cal_container.pack(padx=20, pady=10, fill="x")

    nav_f = ctk.CTkFrame(cal_container, fg_color="transparent")
    nav_f.pack(fill="x", pady=10, padx=10)
    
    cal_vars["lbl_month"] = ctk.CTkLabel(nav_f, text="", font=("Roboto", 14, "bold"))
    
    btn_prev = ctk.CTkButton(nav_f, text="<", width=40, fg_color="transparent", border_color="#1f6aa5", border_width=1, text_color=["black", "white"], command=lambda: change_month(-1))
    btn_next = ctk.CTkButton(nav_f, text=">", width=40, fg_color="transparent", border_color="#1f6aa5", border_width=1, text_color=["black", "white"], command=lambda: change_month(1))
    
    btn_prev.pack(side="left", padx=20)
    cal_vars["lbl_month"].pack(side="left", expand=True)
    btn_next.pack(side="right", padx=20)

    cal_vars["grid_frame"] = ctk.CTkFrame(cal_container, fg_color="transparent")
    cal_vars["grid_frame"].pack(padx=10, pady=5)

    render_calendar()
    return TAB_KEY

def change_month(delta):
    cal_vars["month"] += delta
    if cal_vars["month"] > 12:
        cal_vars["month"] = 1
        cal_vars["year"] += 1
    elif cal_vars["month"] < 1:
        cal_vars["month"] = 12
        cal_vars["year"] -= 1
    render_calendar()

def render_calendar():
    grid = cal_vars["grid_frame"]
    for w in grid.winfo_children(): w.destroy()

    y, m = cal_vars["year"], cal_vars["month"]
    cal_vars["lbl_month"].configure(text=f"{y}-{m:02d}")
    overrides = load_calendar_overrides_data()

    days = [i18n.get(f"day_short_{i}") for i in range(7)]
    for col, d_name in enumerate(days):
        ctk.CTkLabel(grid, text=d_name, font=("Roboto", 12, "bold"), width=50).grid(row=0, column=col, pady=2)

    cal_matrix = calendar.monthcalendar(y, m)
    for r_idx, week in enumerate(cal_matrix):
        for c_idx, day in enumerate(week):
            if day == 0: continue
            date_str = f"{y}-{m:02d}-{day:02d}"
            
            btn_color = ["#e0e0e0", "#333"]
            txt_color = ["black", "white"]
            val_str = None
            
            if date_str in overrides:
                val = int(overrides[date_str])
                if val == 0: 
                    btn_color = "#c0392b"
                    txt_color = "white"
                    val_str = "BLOKADA"
                else: 
                    btn_color = "#1f6aa5"
                    txt_color = "white"
                    val_str = f"{val}m"

            # Sztywny box
            box = ctk.CTkFrame(grid, width=54, height=54, fg_color=btn_color, corner_radius=8)
            box.grid(row=r_idx+1, column=c_idx, padx=3, pady=3)
            box.pack_propagate(False)
            
            lbl_d = ctk.CTkLabel(box, text=str(day), font=("Roboto", 13, "bold"), text_color=txt_color)
            lbl_d.pack(pady=(5, 0) if val_str else (15, 0))
            
            lbl_m = None
            if val_str:
                lbl_m = ctk.CTkLabel(box, text=val_str, font=("Roboto", 9), text_color=txt_color)
                lbl_m.pack()

            def bind_events(w, d=date_str):
                w.bind("<Button-1>", lambda e, ds=d: on_left_click(ds))
                w.bind("<Button-3>", lambda e, ds=d: on_right_click(ds))
                w.bind("<Button-2>", lambda e, ds=d: on_right_click(ds)) # Mac
            
            bind_events(box)
            bind_events(lbl_d)
            if lbl_m: bind_events(lbl_m)

def on_left_click(date_str):
    overrides = load_calendar_overrides_data()
    current_val = overrides.get(date_str, 60)
    
    def save_new_val(val):
        overrides = load_calendar_overrides_data()
        overrides[date_str] = str(val)
        save_calendar_overrides_data(overrides)
        render_calendar()
        
    LimitDialog(cal_vars["grid_frame"], date_str, current_val, save_new_val)

def on_right_click(date_str):
    overrides = load_calendar_overrides_data()
    if date_str in overrides:
        del overrides[date_str]
        save_calendar_overrides_data(overrides)
        render_calendar()

def load_std_limits():
    if os.path.exists(PLIK_LIMITOW):
        try:
            with open(PLIK_LIMITOW, "r", encoding="utf-8") as f:
                content = f.read()
                return json.loads(security.crypt_data(base64.b64decode(content).decode()))
        except: pass
    return {}

def save_trigger():
    limits_data = {key: str(var.get()) for key, var in limits_vars.items()}
    try:
        encrypted = base64.b64encode(security.crypt_data(json.dumps(limits_data)).encode()).decode()
        with open(PLIK_LIMITOW, "w", encoding="utf-8") as f: f.write(encrypted)
    except: pass

def load_calendar_overrides_data():
    if os.path.exists(PLIK_KALENDARZA):
        try:
            with open(PLIK_KALENDARZA, "r", encoding="utf-8") as f: return json.load(f)
        except: pass
    return {}

def save_calendar_overrides_data(data):
    with open(PLIK_KALENDARZA, "w", encoding="utf-8") as f: json.dump(data, f, indent=4)