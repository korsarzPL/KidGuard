import tkinter as tk
import os
import sys
import urllib.request
import json
import time
import ui_counter
import wizard
from i18n import i18n
import engine
import _PR_website
import _PR_aktualizacja

APP_VERSION = "1.0.0"
VERSION_URL = "https://raw.githubusercontent.com/korsarzPL/KidGuard/main/version.json"


def cleanup_after_update():
    """Sprzątanie śmieci po aktualizacji."""
    if not getattr(sys, 'frozen', False):
        return

    base_dir = os.path.dirname(os.path.abspath(sys.executable))
    exe_path = os.path.abspath(sys.executable)

    candidates = [
        exe_path + ".backup",
        exe_path + ".old",
        exe_path + ".new",
        os.path.join(base_dir, "updater.zip"),
        os.path.join(base_dir, "KidGuard_update.zip"),
        os.path.join(base_dir, "update_temp.zip"),
        os.path.join(base_dir, "version.json"),
    ]

    for path in candidates:
        if os.path.exists(path):
            try:
                os.remove(path)
            except:
                pass

    # Spróbuj usunąć updater.exe (jeśli nie jest używany)
    updater_exe = os.path.join(base_dir, "updater.exe")
    if os.path.exists(updater_exe):
        try:
            os.remove(updater_exe)
        except:
            pass


def check_for_update():
    """Sprawdza version.json na GitHubie i zwraca dict lub None."""
    try:
        url = f"{VERSION_URL}?t={int(time.time())}"
        req = urllib.request.Request(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data
    except:
        return None


def main():
    cleanup_after_update()

    engine.engine.app_version = APP_VERSION

    # jeśli właśnie po aktualizacji – NIE sprawdzamy od razu ponownie
    just_updated = "--updated" in sys.argv

    if getattr(sys, 'frozen', False) and not just_updated:
        data = check_for_update()
        if data is not None:
            try:
                remote_ver = tuple(map(int, data["version"].split(".")))
                local_ver = tuple(map(int, APP_VERSION.split(".")))
                if remote_ver > local_ver:
                    zip_url = data["url"]  # https://raw.../KidGuard.zip
                    hard_reset = data.get("hard_reset", False)
                    _PR_aktualizacja.perform_update(zip_url, hard_reset, data["version"])
                    return  # updater przejmie sterowanie
            except:
                pass

    if not os.path.exists("main.json"):
        app = wizard.SetupWizard()
        app.root.mainloop()

    try:
        with open("main.json", "r", encoding="utf-8") as f:
            i18n.set_language(json.load(f).get("lang", "pl"))
    except:
        pass

    if just_updated:
        try:
            ver = sys.argv[sys.argv.index("--updated") + 1]
            engine.engine.pending_notifications.append(f"Zaktualizowano do v{ver}")
        except:
            pass

    root = tk.Tk()
    root.overrideredirect(True)
    root.geometry("0x0+0+0")
    root.attributes("-alpha", 0.0)

    app = ui_counter.CounterWindow(root)
    _PR_website.uruchom_serwer_jesli_trzeba()

    root.mainloop()


if __name__ == "__main__":
    main()
