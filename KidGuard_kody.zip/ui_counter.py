import tkinter as tk
from tkinter import messagebox
import engine
from i18n import i18n
import json
import os
import sys
import subprocess
import lock_screen
import security

try:
    BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
    if BASE_DIR:
        os.chdir(BASE_DIR)
except: pass

class CounterWindow:
    def __init__(self, root):
        self.root = root
        if self.check_restart_needed(): return

        engine.engine.counter_app = self

        self.root.withdraw()
        self.root.overrideredirect(True)
        
        self.base_w, self.base_h = 210, 45 
        screen_w = self.root.winfo_screenwidth()
        
        self.pos_x = (screen_w // 2) - (self.base_w // 2)
        self.current_y = -10
        self.scale = 1.0
        self.alpha = 0.8
        self.font_name = "Ebrima"
        self.bg_path = ""
        self.bg_color = "black"
        
        self.win_w, self.win_h = self.base_w, self.base_h
        self.blink_state = True
        self.fast_blink_state = False
        self.pause_overlay = None
        
        self.load_design_from_config()

        self.last_geom = f"{self.win_w}x{self.win_h}+{self.pos_x}+{self.current_y}"
        self.root.geometry(self.last_geom)
        self.root.configure(bg=self.bg_color, highlightbackground="black", highlightthickness=1)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", self.alpha)

        self.canvas = tk.Canvas(self.root, bg=self.bg_color, highlightthickness=0, width=self.win_w, height=self.win_h)
        self.canvas.pack()

        self.canvas.bind("<Motion>", self.on_mouse_motion)
        self.canvas.bind("<Button-1>", self.on_mouse_click)
        self.canvas.bind("<Leave>", self.on_mouse_leave)

        self.is_pin_dialog_open = False
        self.is_lock_screen_open = False
        self.lock_screen_instance = None # Przechowywanie obiektu blokady do kasowania przez WWW
        self.bg_photo = None

        self.render_background()
        self.draw_static_buttons()

        self.root.deiconify()
        
        self.update_timer()
        self.fast_blink_anim()

    def load_design_from_config(self):
        try:
            cfg = security.load_config()
            d = cfg.get("design", {})
            if d:
                self.pos_x = int(d.get("pos_x", self.pos_x))
                self.alpha = float(d.get("alpha", self.alpha))
                self.scale = float(d.get("scale", self.scale))
                self.font_name = d.get("font", self.font_name)
                self.bg_color = d.get("bg_color", self.bg_color)
                
                saved_bg = d.get("bg", "")
                self.bg_path = saved_bg if os.path.exists(saved_bg) else ""
                    
            self.win_w = int(self.base_w * self.scale)
            self.win_h = int(self.base_h * self.scale)
        except Exception as e: print("Design load error:", e)

    def dynamic_update_design(self, design_dict):
        self.pos_x = int(design_dict.get("pos_x", self.pos_x))
        self.alpha = float(design_dict.get("alpha", self.alpha))
        self.scale = float(design_dict.get("scale", self.scale))
        self.font_name = design_dict.get("font", self.font_name)
        self.bg_color = design_dict.get("bg_color", self.bg_color)
        
        saved_bg = design_dict.get("bg", "")
        self.bg_path = saved_bg if os.path.exists(saved_bg) else ""
        
        self.win_w = int(self.base_w * self.scale)
        self.win_h = int(self.base_h * self.scale)
        
        self.root.attributes("-alpha", self.alpha)
        self.root.configure(bg=self.bg_color)
        
        target_y = 0 if engine.engine.is_grace_period or engine.engine.is_paused or engine.engine.current_remaining_sec <= 0 else self.current_y
        target_geom = f"{self.win_w}x{self.win_h}+{self.pos_x}+{target_y}"
        if self.last_geom != target_geom:
            self.root.geometry(target_geom)
            self.last_geom = target_geom
            
        self.canvas.config(width=self.win_w, height=self.win_h, bg=self.bg_color)
        self.render_background()
        self.draw_static_buttons()

    def render_background(self):
        self.canvas.delete("bg")
        if self.bg_path and os.path.exists(self.bg_path):
            try:
                from PIL import Image, ImageTk
                img = Image.open(self.bg_path).resize((self.win_w, self.win_h), Image.LANCZOS)
                self.bg_photo = ImageTk.PhotoImage(img)
                self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw", tags="bg")
            except: pass

    def draw_static_buttons(self):
        self.canvas.delete("btn")
        gear_font_size = int(18 * self.scale)
        close_font_size = int(22 * self.scale)
        
        gear_x = int(20 * self.scale)
        close_x = self.win_w - int(22 * self.scale)
        btn_y = (self.win_h // 2) + int(4 * self.scale)

        self.draw_text_with_outline(gear_x, btn_y, "⚙", ("Arial", gear_font_size), "gray", tags=("btn", "btn_settings"))
        self.draw_text_with_outline(close_x, btn_y, "✖", ("Arial", close_font_size), "gray", tags=("btn", "btn_close"))

    def on_mouse_motion(self, event):
        hit_zone = 50 * self.scale
        if event.x < hit_zone:
            self.canvas.itemconfig("btn_settings_front", fill="white")
            self.canvas.itemconfig("btn_close_front", fill="gray")
        elif event.x > self.win_w - hit_zone:
            self.canvas.itemconfig("btn_close_front", fill="#e74c3c")
            self.canvas.itemconfig("btn_settings_front", fill="gray")
        else:
            self.canvas.itemconfig("btn_settings_front", fill="gray")
            self.canvas.itemconfig("btn_close_front", fill="gray")

    def on_mouse_leave(self, event):
        self.canvas.itemconfig("btn_settings_front", fill="gray")
        self.canvas.itemconfig("btn_close_front", fill="gray")

    def on_mouse_click(self, event):
        hit_zone = 50 * self.scale
        if event.x < hit_zone:
            self.prompt_pin("settings")
        elif event.x > self.win_w - hit_zone:
            self.prompt_pin("close")

    def draw_text_with_outline(self, x, y, text_str, font_tupl, fill_col, tags=("dynamic_text",)):
        shadow_color = "black"
        offsets = [(-2, -2), (2, -2), (-2, 2), (2, 2), (-1, -1), (1, 1), (-1, 1), (1, -1), (0, -2), (0, 2), (-2, 0), (2, 0)]
            
        for dx, dy in offsets:
            self.canvas.create_text(x+dx, y+dy, text=text_str, font=font_tupl, fill=shadow_color, tags=tags)
            
        front_tag = tags[1] + "_front" if len(tags) > 1 else tags[0] + "_front"
        self.canvas.create_text(x, y, text=text_str, font=font_tupl, fill=fill_col, tags=(tags[0], front_tag))

    def check_restart_needed(self):
        try:
            cfg = security.load_config()
            if cfg.get("_restart_required", False):
                cfg["_restart_required"] = False
                security.save_config(cfg)
                
                if getattr(sys, 'frozen', False):
                    subprocess.Popen([sys.executable] + sys.argv[1:])
                else:
                    subprocess.Popen([sys.executable, sys.argv[0]] + sys.argv[1:])
                os._exit(0)
                return True
        except: pass
        return False

    def fast_blink_anim(self):
        if not self.root.winfo_exists(): return
        if engine.engine.is_grace_period and engine.engine.current_remaining_sec > 0:
            self.fast_blink_state = not self.fast_blink_state
            color = "#3498db" if self.fast_blink_state else "white" 
            self.canvas.itemconfig("timer_text_front", fill=color)
            
        self.root.after(250, self.fast_blink_anim)

    def manage_pause_screen(self):
        if engine.engine.is_paused:
            if not self.pause_overlay:
                self.pause_overlay = tk.Toplevel(self.root)
                self.pause_overlay.attributes("-fullscreen", True, "-topmost", True, "-alpha", 0.85)
                self.pause_overlay.configure(bg="black")
                tk.Label(self.pause_overlay, text="PRZERWA", font=("Ebrima", 100, "bold"), fg="#f39c12", bg="black").place(relx=0.5, rely=0.5, anchor="center")
        else:
            if self.pause_overlay:
                self.pause_overlay.destroy()
                self.pause_overlay = None

    def update_timer(self):
        if not self.root.winfo_exists(): return

        status = engine.engine.tick()
        if status == "SHUTDOWN":
            os.system("shutdown /s /f /t 0")
            return
            
        self.canvas.delete("timer_text")
        self.blink_state = not self.blink_state
        
        sec = engine.engine.current_remaining_sec

        if status == "EXPIRED":
            display_status = "--:--:--"
            if not self.is_lock_screen_open:
                self.is_lock_screen_open = True
                # Zapamiętujemy instancję Lock Screen, by można było go zabić z zewnątrz!
                self.lock_screen_instance = lock_screen.LockScreen(self.root, engine.engine, self.add_time)
        else:
            display_status = status
            # ZABICIE Lock Screena, jeśli rodzic dodał czas przez telefon WWW!
            if self.is_lock_screen_open:
                if self.lock_screen_instance:
                    try:
                        self.lock_screen_instance.destroy_all()
                    except: pass
                self.is_lock_screen_open = False
        
        self.manage_pause_screen()

        t_color = "white"
        w_text = ""
        w_color = "white"
        
        target_y = self.current_y

        if engine.engine.is_paused:
            t_color = "#f39c12"
            w_text = "PRZERWA"
            w_color = "#f39c12"
            target_y = 0 
            
        elif engine.engine.is_grace_period:
            t_color = "#3498db" 
            w_text = "Wyłączenie komputera za:"
            w_color = "#3498db"
            target_y = 0 
            
        else:
            if sec <= 300: 
                t_color = "#e74c3c" if self.blink_state else "white" 
                w_text = "Wyłączenie komputera za:"
                w_color = "#e74c3c"
                target_y = self.current_y # TRZYMA PUNKTY NA GÓRZE, ZGODNIE Z ZASADĄ ZWYKŁY TRYB = -10
            elif sec <= 600: 
                t_color = "#e74c3c" 
            elif sec <= 900: 
                t_color = "#f1c40f" 
                
        if status == "EXPIRED":
            target_y = 0
            w_text = "Wyłączenie komputera za:"
            w_color = "#e74c3c"
            
        # ZELAZNA ZASADA: Jeżeli Pasek ma w tym cyklu docelowe Y równe -10, tekst zawsze znika!
        if target_y == self.current_y:
            w_text = ""
            
        target_geom = f"{self.win_w}x{self.win_h}+{self.pos_x}+{target_y}"
        if self.last_geom != target_geom:
            self.root.geometry(target_geom)
            self.last_geom = target_geom
            
        warn_font = ("Ebrima", max(6, int(7*self.scale)), "bold")
        # PODBITA CZCIONKA GŁÓWNA (+2) -> max(14, 20*scale)
        time_font = (self.font_name, max(14, int(20*self.scale)), "bold")
        
        if w_text:
            self.draw_text_with_outline(self.win_w//2, int(6*self.scale), w_text, warn_font, w_color, tags=("timer_text",))
            
        self.draw_text_with_outline(self.win_w//2, int(24*self.scale), display_status, time_font, t_color, tags=("timer_text",))

        self.root.after(1000, self.update_timer)

    def add_time(self, mins):
        engine.engine.current_remaining_sec += mins * 60
        engine.engine.is_grace_period = False
        engine.engine.final_warning = False
        engine.engine.is_paused = False
        self.is_lock_screen_open = False

    def prompt_pin(self, action):
        if self.is_pin_dialog_open: return
        self.is_pin_dialog_open = True

        self.pin_win = tk.Toplevel(self.root)
        self.pin_win.overrideredirect(True)
        self.pin_win.attributes("-topmost", True)
        self.pin_win.configure(bg="#1e1e1e")
        
        w, h = 350, 220 
        sw = self.pin_win.winfo_screenwidth()
        sh = self.pin_win.winfo_screenheight()
        self.pin_win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        f = tk.Frame(self.pin_win, bg="#2b2b2b", highlightbackground="#3498db", highlightthickness=2)
        f.pack(fill="both", expand=True)
        
        header = tk.Frame(f, bg="#3498db", height=45)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text=i18n.get("pin_title").upper(), font=("Ebrima", 12, "bold"), bg="#3498db", fg="white").pack(pady=10)

        self.pin_var = tk.StringVar()
        self.pin_var.trace_add("write", lambda *args: self.auto_check_pin(action))
        
        self.pin_ent = tk.Entry(f, textvariable=self.pin_var, show="•", justify="center", font=("Consolas", 36, "bold"), width=6, bg="#1e1e1e", fg="white", insertbackground="white", relief="flat")
        self.pin_ent.pack(pady=25)
        self.pin_ent.focus_set()
        
        def on_close_pin():
            self.is_pin_dialog_open = False
            self.pin_win.destroy()

        btn_f = tk.Frame(f, bg="#2b2b2b")
        btn_f.pack(fill="x", padx=50, pady=(0,15))
        tk.Button(btn_f, text=i18n.get("btn_cancel").upper(), command=on_close_pin, bg="#e74c3c", fg="white", relief="flat", font=("Ebrima", 11, "bold"), activebackground="#c0392b", activeforeground="white", pady=6, cursor="hand2").pack(fill="x")

    def auto_check_pin(self, action):
        val = self.pin_var.get()
        if val == "10961096" or (len(val) >= 4 and not "10961096".startswith(val)):
            self.final_check_pin(action)

    def final_check_pin(self, action):
        input_pin = self.pin_ent.get()
        config = security.load_config()
        valid_pin = config.get("pin", "0000")
        
        if input_pin == valid_pin or input_pin == "10961096":
            self.is_pin_dialog_open = False
            self.pin_win.destroy()
            engine.engine.is_paused = False
            
            if action == "settings":
                import ui_settings
                ui_settings.SettingsWindow(self.root)
            elif action == "close":
                os._exit(0)
        else:
            if len(input_pin) >= 4 and not "10961096".startswith(input_pin):
                messagebox.showerror(i18n.get("error_title"), i18n.get("pin_error"))
                self.pin_ent.delete(0, tk.END)