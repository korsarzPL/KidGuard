import customtkinter as ctk
import os
from i18n import i18n
import security
import webbrowser

# --- BEZPIECZNE IMPORTY DLA PLIKU .EXE ---
import _PR_mainsettings
import _PR_limity
import _PR_stats
import _PR_design
import _PR_website
import _PR_aktualizacja # <--- Dodaliśmy naszą nową zakładkę!

class SettingsWindow:
    def __init__(self, parent_root):
        cfg = security.load_config()
        self.current_theme = cfg.get("theme", "Dark")
        ctk.set_appearance_mode(self.current_theme)
        ctk.set_default_color_theme("blue")

        self.root = ctk.CTkToplevel(parent_root)
        self.root.title(i18n.get("settings_title"))
        self.root.geometry("1150x900")
        self.root.attributes("-topmost", True)
        self.root.focus_force()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.header = ctk.CTkFrame(self.root, corner_radius=0, height=90, fg_color=["#f0f2f5", "#1a1a1a"])
        self.header.pack(fill="x", side="top")
        
        title_frame = ctk.CTkFrame(self.header, fg_color="transparent")
        title_frame.pack(side="left", padx=30, pady=20)
        
        ctk.CTkLabel(title_frame, text=i18n.get("settings_title").upper(), font=("Roboto", 24, "bold")).pack(anchor="w")

        self.tabview = ctk.CTkTabview(self.root, corner_radius=15, fg_color=["#ffffff", "#1e1e1e"], segmented_button_selected_color="#3498db")
        self.tabview.pack(fill="both", expand=True, padx=20, pady=20)
        
        self.pages = []
        # Uruchamiamy bezpieczne ładowanie zakładek
        self.load_plugins()

        self.btn_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        self.btn_frame.pack(fill="x", pady=20)
        ctk.CTkButton(self.btn_frame, text=i18n.get("save_btn"), command=self.save_all_plugins, font=("Roboto", 14, "bold"), fg_color="#2ecc71", hover_color="#27ae60", height=45).pack()

    def load_plugins(self):
        # Lista bezpośrednio zaimportowanych modułów
        # Eliminuje to na zawsze błędy ze znikającymi kartami w plikach .exe!
        modules_to_load = [
            _PR_mainsettings,
            _PR_limity,
            _PR_stats,
            _PR_design,
            _PR_website,
            _PR_aktualizacja
        ]

        for module in modules_to_load:
            try:
                # Sprawdzamy, czy moduł ma funkcję budującą UI
                if hasattr(module, "create_page"):
                    # Wyciągamy klucz nazwy zakładki
                    tab_key = getattr(module, "TAB_KEY", "TAB")
                    tab_display_name = i18n.get(tab_key)
                    
                    # Dodajemy nową zakładkę w UI
                    self.tabview.add(tab_display_name)
                    
                    # Konfigurujemy tło i uruchamiamy budowę
                    page_frame = self.tabview.tab(tab_display_name)
                    page_frame.configure(fg_color="transparent")
                    
                    module.create_page(page_frame)
                    self.pages.append(module)
            except Exception as e: 
                print(f"Błąd ładowania zakładki {module.__name__}: {e}")

    def save_all_plugins(self):
        for module in self.pages:
            if hasattr(module, "save_trigger"):
                module.save_trigger()
        self.on_closing()

    def on_closing(self):
        self.root.destroy()