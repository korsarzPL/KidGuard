import customtkinter as ctk
import os
import sys
import engine
import security
from i18n import i18n

ui_vars = {}
TAB_KEY = "tab_main_settings"

def create_page(parent):
    config = security.load_config()
            
    container = ctk.CTkScrollableFrame(parent, fg_color="transparent")
    container.pack(fill="both", expand=True)

    time_frame = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    time_frame.pack(fill="x", pady=(0, 15), ipady=5)
    
    txt_f = ctk.CTkFrame(time_frame, fg_color="transparent")
    txt_f.pack(side="left", fill="x", expand=True, padx=20, pady=15)
    ctk.CTkLabel(txt_f, text=i18n.get("set_current_time"), font=("Roboto", 16, "bold"), text_color="#e74c3c").pack(anchor="w")
    ctk.CTkLabel(txt_f, text=i18n.get("desc_current_time"), font=("Roboto", 11), text_color="gray", wraplength=450, justify="left").pack(anchor="w")
    
    current_minutes = engine.engine.current_remaining_sec // 60
    ui_vars["current_time"] = ctk.StringVar(value=str(current_minutes))
    
    entry_f = ctk.CTkFrame(time_frame, fg_color="transparent")
    entry_f.pack(side="right", padx=20)
    ctk.CTkEntry(entry_f, textvariable=ui_vars["current_time"], width=80, height=40, font=("Roboto Mono", 18, "bold"), justify="center").pack(side="left")
    ctk.CTkLabel(entry_f, text=i18n.get("min_label"), font=("Roboto", 12)).pack(side="left", padx=5)

    lang_frame = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    lang_frame.pack(fill="x", pady=(0, 15), ipady=5)
    
    lbl_f = ctk.CTkFrame(lang_frame, fg_color="transparent")
    lbl_f.pack(side="left", padx=20, pady=15)
    ctk.CTkLabel(lbl_f, text=i18n.get("set_language"), font=("Roboto", 14, "bold")).pack(anchor="w")
    ctk.CTkLabel(lbl_f, text=i18n.get("desc_language"), font=("Roboto", 11), text_color="gray").pack(anchor="w")

    lang_files = [f.split('_')[1].split('.')[0] for f in os.listdir('.') if f.startswith('lang_') and f.endswith('.json')]
    ui_vars["lang"] = ctk.StringVar(value=config.get("lang", "pl"))
    def preview_lang(*args): i18n.set_language(ui_vars["lang"].get())
    ui_vars["lang"].trace_add("write", preview_lang)
    ctk.CTkComboBox(lang_frame, values=lang_files, variable=ui_vars["lang"], width=100, font=("Roboto", 12)).pack(side="right", padx=20)

    settings_group = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    settings_group.pack(fill="x", pady=10, ipady=5)

    def add_row(label_key, description_key, widget_type, var_name, is_pin=False):
        row = ctk.CTkFrame(settings_group, fg_color="transparent")
        row.pack(fill="x", pady=15, padx=10)
        
        txt_f = ctk.CTkFrame(row, fg_color="transparent")
        txt_f.pack(side="left", fill="x", expand=True, padx=10)
        ctk.CTkLabel(txt_f, text=i18n.get(label_key), font=("Roboto", 14, "bold")).pack(anchor="w")
        ctk.CTkLabel(txt_f, text=i18n.get(description_key), font=("Roboto", 11), text_color="gray", wraplength=450, justify="left").pack(anchor="w")
        
        if widget_type == "entry":
            var = ctk.StringVar(value=str(config.get(var_name, "")))
            ui_vars[var_name] = var
            show_char = "*" if is_pin else ""
            ctk.CTkEntry(row, textvariable=var, width=120, height=35, font=("Roboto Mono", 13), show=show_char, justify="center").pack(side="right", padx=10)
        elif widget_type == "switch":
            var = ctk.BooleanVar(value=config.get(var_name, False))
            ui_vars[var_name] = var
            ctk.CTkSwitch(row, text="", variable=var, button_color="#1f6aa5", progress_color="#1f6aa5").pack(side="right", padx=10)

    add_row("set_parent_pin", "desc_parent_pin", "entry", "pin", True)
    add_row("set_extra_time_pin", "desc_extra_time_pin", "entry", "extra_time_pin")
    
    ctk.CTkFrame(settings_group, height=2, fg_color=["#eee", "#333"]).pack(fill="x", padx=20, pady=5)
    
    add_row("set_show_blue_btn", "desc_show_blue_btn", "switch", "show_blue_btn")
    add_row("set_autostart", "desc_autostart", "switch", "autostart")

    return TAB_KEY

def save_trigger():
    try:
        new_min = int(ui_vars["current_time"].get())
        new_sec = new_min * 60
        if new_sec > 0 and engine.engine.is_grace_period:
            engine.engine.is_grace_period = False 
            engine.engine.final_warning = False   
        engine.engine.current_remaining_sec = new_sec
    except: pass

    new_config = security.load_config()
    new_config["pin"] = ui_vars["pin"].get()
    new_config["lang"] = ui_vars["lang"].get()
    new_config["extra_time_pin"] = ui_vars["extra_time_pin"].get()
    new_config["show_blue_btn"] = ui_vars["show_blue_btn"].get()
    new_config["autostart"] = ui_vars["autostart"].get()
    
    manage_autostart(new_config["autostart"])
    security.save_config(new_config)

def manage_autostart(enabled):
    import winreg
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    app_name = "KidGuard"
    
    if getattr(sys, 'frozen', False):
        exe_path = f'"{sys.executable}"'
    else:
        pythonw_path = sys.executable.replace("python.exe", "pythonw.exe")
        main_script = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "main.py")
        exe_path = f'"{pythonw_path}" "{main_script}"'
        
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        if enabled: winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, exe_path)
        else:
            try: winreg.DeleteValue(key, app_name)
            except: pass
        winreg.CloseKey(key)
    except: pass