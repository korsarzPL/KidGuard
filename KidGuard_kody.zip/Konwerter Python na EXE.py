# konwerter_exe_fixed.py
import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import shutil
import tempfile

# -------------------------
# PROSTE USTAWIENIA
# -------------------------
PYINSTALLER_EXEC = "pyinstaller"  # zakładamy, że pyinstaller jest w PATH
# -------------------------

class PyToExeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Konwerter Python → EXE (poprawiona wersja)")
        self.root.geometry("720x460")
        self.root.resizable(False, False)

        # USTALENIE FOLDERU APLIKACJI (ważne przy .exe spakowanym przez PyInstaller)
        if getattr(sys, "frozen", False):
            # sys.argv[0] wskazuje na rzeczywisty plik exe (nie katalog tymczasowy _MEI)
            self.current_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        else:
            self.current_dir = os.path.dirname(os.path.abspath(__file__))

        self.py_path = tk.StringVar()
        self.ico_path = tk.StringVar()
        self.export_dir = tk.StringVar()

        self.detect_files()

        # --- Interfejs ---
        tk.Label(root, text="Plik .py:", font=("Arial", 12, "bold")).pack(anchor="w", padx=20, pady=(12, 0))
        tk.Entry(root, textvariable=self.py_path, width=95).pack(padx=20, pady=4)
        tk.Button(root, text="Wybierz plik .py", command=self.choose_py).pack(pady=(0, 10))

        tk.Label(root, text="Plik .ico (opcjonalnie):", font=("Arial", 12, "bold")).pack(anchor="w", padx=20)
        tk.Entry(root, textvariable=self.ico_path, width=95).pack(padx=20, pady=4)
        tk.Button(root, text="Wybierz plik .ico", command=self.choose_ico).pack(pady=(0, 10))

        tk.Label(root, text="Folder eksportu (domyślnie: <folder_aplikacji>\\Eksport):", font=("Arial", 12, "bold")).pack(anchor="w", padx=20)
        frame = tk.Frame(root)
        frame.pack(padx=20, pady=4, fill="x")
        tk.Entry(frame, textvariable=self.export_dir, width=82, state="readonly").pack(side="left", fill="x", expand=True)
        tk.Button(frame, text="Zmień folder eksportu", command=self.choose_export_dir).pack(side="left", padx=8)

        # Pasek postępu (dynamiczny)
        self.progress = ttk.Progressbar(root, length=600, mode="indeterminate")
        self.progress.pack(pady=16)

        self.status_label = tk.Label(root, text="", font=("Arial", 11), fg="gray")
        self.status_label.pack()

        tk.Button(root, text="Konwertuj do EXE", font=("Arial", 14, "bold"),
                  bg="#4caf50", fg="white", width=24, height=1,
                  command=self.convert).pack(pady=12)

        # mały tekst z informacją o folderze aplikacji
        tk.Label(root, text=f"Folder aplikacji: {self.current_dir}", font=("Arial", 8), fg="gray").pack(side="bottom", pady=6)

    # --- wykrywanie plików w folderze aplikacji ---
    def detect_files(self):
        try:
            files = os.listdir(self.current_dir)
        except Exception:
            files = []
        py_files = [f for f in files if f.lower().endswith(".py") and f != os.path.basename(__file__)]
        ico_files = [f for f in files if f.lower().endswith(".ico")]

        # jeśli jest dokładnie jeden plik .py w folderze aplikacji -> ustaw
        if len(py_files) == 1:
            self.py_path.set(os.path.join(self.current_dir, py_files[0]))
        # jeśli jest więcej niż 1 -> nie podpowiadamy
        # jeśli jest zero -> puste pole

        if len(ico_files) == 1:
            self.ico_path.set(os.path.join(self.current_dir, ico_files[0]))

        export_folder = os.path.join(self.current_dir, "Eksport")
        os.makedirs(export_folder, exist_ok=True)
        self.export_dir.set(export_folder)

    # --- wybieranie plików ręcznie ---
    def choose_py(self):
        path = filedialog.askopenfilename(initialdir=self.current_dir, filetypes=[("Pliki Python", "*.py")])
        if path:
            self.py_path.set(path)

    def choose_ico(self):
        path = filedialog.askopenfilename(initialdir=self.current_dir, filetypes=[("Ikony", "*.ico")])
        if path:
            self.ico_path.set(path)

    def choose_export_dir(self):
        path = filedialog.askdirectory(initialdir=self.current_dir)
        if path:
            self.export_dir.set(path)

    # --- konwersja ---
    def convert(self):
        py_file = self.py_path.get().strip()
        ico_file = self.ico_path.get().strip()
        export_main = self.export_dir.get().strip()

        if not py_file or not os.path.isfile(py_file):
            messagebox.showerror("Błąd", "Nie znaleziono pliku .py — wybierz plik do konwersji.")
            return

        # utwórz podfolder w Eksport o nazwie pliku py (bez rozszerzenia)
        py_name = os.path.splitext(os.path.basename(py_file))[0]
        export_subfolder = os.path.join(export_main, py_name)
        os.makedirs(export_subfolder, exist_ok=True)

        # Start progress
        self.status_label.config(text="Start konwersji — uruchamiam PyInstaller...")
        self.progress.start(12)
        self.root.update_idletasks()

        # uruchom w tle
        threading.Thread(target=self.run_conversion, args=(py_file, ico_file, export_subfolder), daemon=True).start()

    def find_tcl_tk_dirs(self):
        """
        Zwraca tuple (tcl_dir, tk_dir) - lokalizacje bibliotek tcl/tk dla bieżącego Pythona.
        Używamy tkinter.Tcl() żeby dostać 'info library' (działa w standardowym Pythonie).
        """
        try:
            import tkinter
            t = tkinter.Tcl()
            tcl_lib = t.eval('info library')  # np. C:/Python39/tcl/tcl8.6
            # spróbuj odgadnąć katalog tk na podstawie tcl
            tcl_dir = os.path.normpath(tcl_lib)
            # często tk jest w tym samym katalogu rodzicu: .../tcl/tk8.6  albo .../tcl
            possible_tk = os.path.join(os.path.dirname(tcl_dir), "tk")
            if os.path.exists(possible_tk):
                tk_dir = possible_tk
            else:
                # fallback: spróbuj znaleźć folder 'tk' w instalacji Pythona
                python_dir = os.path.dirname(sys.executable)
                tk_dir_guess = os.path.join(python_dir, "tcl", "tk8.6")
                if os.path.exists(tk_dir_guess):
                    tk_dir = tk_dir_guess
                else:
                    tk_dir = ""
            return tcl_dir, tk_dir
        except Exception:
            return "", ""

    def run_conversion(self, py_file, ico_file, export_subfolder):
        py_folder = os.path.dirname(py_file)
        py_name = os.path.basename(py_file)

        # stwórz tymczasowy katalog do pracy (workpath/specpath)
        temp_build = tempfile.mkdtemp(prefix="pyconv_build_")

        # znajdź tcl/tk aby włączyć do EXE — to rozwiązuje błąd "_tk_data not found"
        tcl_dir, tk_dir = self.find_tcl_tk_dirs()

        # Budujemy polecenie PyInstaller
        # używamy --distpath na docelowy folder export_subfolder (bezpośrednio tam trafi exe)
        cmd = [
            PYINSTALLER_EXEC,
            "--onefile",
            "--windowed",
            f"--distpath={export_subfolder}",
            f"--workpath={temp_build}",
            f"--specpath={temp_build}"
        ]

        # add-data dla tcl/tk (jeśli znalezione)
        if tcl_dir:
            # Windows: format "src;dest" (pyinstaller expects semicolon)
            cmd.append(f'--add-data={tcl_dir};tcl')
        if tk_dir:
            cmd.append(f'--add-data={tk_dir};tk')

        # ikona
        if ico_file and os.path.isfile(ico_file):
            cmd.append(f"--icon={ico_file}")

        # plik docelowy
        cmd.append(py_file)

        # Uruchom PyInstaller bez widocznego okna (CREATE_NO_WINDOW) — działa na Windows
        try:
            # Windows-only flag — jeśli na innym systemie, można pominąć
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NO_WINDOW

            # Uruchamiamy
            subprocess.run(cmd, cwd=py_folder, check=True, creationflags=creationflags)

            # zakończona konwersja
            self.progress.stop()
            self.status_label.config(text=f"Gotowe — EXE w: {export_subfolder}")
            messagebox.showinfo("Sukces", f"Konwersja zakończona.\nPlik EXE zapisano w:\n{export_subfolder}")

        except subprocess.CalledProcessError as cpe:
            self.progress.stop()
            self.status_label.config(text="Błąd konwersji — sprawdź log lub konsolę")
            messagebox.showerror("Błąd PyInstaller", f"PyInstaller zwrócił błąd:\n{cpe}")
        except Exception as e:
            self.progress.stop()
            self.status_label.config(text="Błąd konwersji")
            messagebox.showerror("Błąd", f"Wystąpił błąd:\n{e}")
        finally:
            # spróbuj usunąć tymczasowy katalog build/spec
            try:
                shutil.rmtree(temp_build, ignore_errors=True)
            except:
                pass

# uruchomienie
if __name__ == "__main__":
    root = tk.Tk()
    app = PyToExeApp(root)
    root.mainloop()
