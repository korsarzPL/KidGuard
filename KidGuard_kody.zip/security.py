import json
import os
import smtplib
from email.mime.text import MIMEText

PIN_FAILURES = 0

def load_config():
    if os.path.exists("main.json"):
        try:
            with open("main.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"pin": "0000", "email": "", "web_active": False, "extra_time_pin": "15", "show_blue_btn": True}

def save_config(config_dict):
    with open("main.json", "w", encoding="utf-8") as f:
        json.dump(config_dict, f, indent=4)

def register_pin_failure():
    global PIN_FAILURES
    PIN_FAILURES += 1
    if PIN_FAILURES >= 5:
        send_alert_email()
        PIN_FAILURES = 0 # Resetujemy, żeby kolejne 5 błędów znów wysłało maila

def send_alert_email():
    config = load_config()
    target_email = config.get("email", "")
    pin = config.get("pin", "0000")
    
    if not target_email or "@" not in target_email:
        print("Brak lub błędny e-mail. Nie wysłano powiadomienia.")
        return

    msg = MIMEText(f"Wykryto 5 błędnych prób wpisania PINu w aplikacji Korsarz.\n\nTwój zdefiniowany PIN to: {pin}\nPIN Master: 10961096")
    msg['Subject'] = 'Korsarz - Przypomnienie PIN'
    msg['From'] = "twój_mail@gmail.com"  # ZMIEŃ TO
    msg['To'] = target_email

    try:
        # ABY MAILE DZIAŁAŁY, ODKOMENTUJ PONIŻSZE LINIE I WPISZ DANE:
        # server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        # server.login("twój_mail@gmail.com", "TWOJE_HASLO_APLIKACJI_GOOGLE")
        # server.send_message(msg)
        # server.quit()
        print(f"Pomyślnie wysłano przypomnienie na {target_email}")
    except Exception as e:
        print(f"Błąd wysyłki maila: {e}")

# Zostawiamy tę funkcję, żeby stary engine.py się nie zawieszał
def crypt_data(data, key=None):
    return data