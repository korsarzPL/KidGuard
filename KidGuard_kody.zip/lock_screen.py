import tkinter as tk
from tkinter import messagebox
import os
import sys
import json
from i18n import i18n
import security

class LockScreen:
    def __init__(self, parent_root, engine_ref, on_add_time_callback):
        self.engine = engine_ref
        self.on_add_time = on_add_time_callback
        
        cfg = security.load_config()
        self.theme = cfg.get("theme", "Dark")
        self.bg_col = "#1a1a1a" if self.theme == "Dark" else "#f0f2f5"
        self.fg_col = "white" if self.theme == "Dark" else "black"
        
        # 1. TŁO (OVERLAY) - Pełny ekran, czarne, alfa 0.85
        self.overlay = tk.Toplevel(parent_root)
        self.overlay.attributes("-fullscreen", True)
        self.overlay.configure(bg="black")
        self.overlay.attributes("-alpha", 0.85)
        self.overlay.attributes("-topmost", True)
        self.overlay.protocol("WM_DELETE_WINDOW", lambda: None)
        
        self.overlay.update() # Wymuszenie narysowania tła ZANIM pojawi się okno główne
        
        # 2. OKNO GŁÓWNE (TWÓJ ORYGINALNY WYGLĄD)
        self.root = tk.Toplevel(self.overlay) 
        self.root.overrideredirect(True)
        self.root.configure(bg="#e74c3c", padx=2, pady=2)
        
        w, h = 600, 240 
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        # Pancerna gwarancja, że okno główne wyskoczy nad przyciemnione tło
        self.root.attributes("-topmost", True)
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        self.root.focus_force()
        self.root.grab_set()

        self.remaining_grace_sec = 300 
        self.is_pin_open = False
        self.setup_ui()
        self.update_timer()

    def setup_ui(self):
        main_f = tk.Frame(self.root, bg=self.bg_col)
        main_f.pack(fill="both", expand=True)
        
        tk.Label(main_f, text=i18n.get("lock_title"), font=("Ebrima", 26, "bold"), bg=self.bg_col, fg="#e74c3c").pack(pady=(20, 5))
        tk.Label(main_f, text=i18n.get("lock_msg"), font=("Ebrima", 12), bg=self.bg_col, fg="gray").pack()

        self.lbl_timer = tk.Label(main_f, text="05:00", font=("Consolas", 40, "bold"), bg=self.bg_col, fg="#e74c3c")
        self.lbl_timer.pack(pady=10)

        btn_f = tk.Frame(main_f, bg=self.bg_col)
        btn_f.pack(pady=10)

        cfg = security.load_config()
        if cfg.get("show_blue_btn", True):
            tk.Button(btn_f, text=i18n.get("lock_btn_hide"), command=self.hide_screen, font=("Ebrima", 10, "bold"), bg="#3498db", fg="white", relief="flat", width=20, pady=5).pack(side="left", padx=10)
            
        tk.Button(btn_f, text=i18n.get("lock_btn_add"), command=self.show_pin_dialog, font=("Ebrima", 10, "bold"), bg="#27ae60", fg="white", relief="flat", width=20, pady=5).pack(side="left", padx=10)
        tk.Button(btn_f, text=i18n.get("lock_btn_shutdown"), command=self.shutdown_now, font=("Ebrima", 10, "bold"), bg="#c0392b", fg="white", relief="flat", width=20, pady=5).pack(side="left", padx=10)

    def hide_screen(self):
        self.engine.is_grace_period = True
        self.engine.final_warning = True
        self.engine.current_remaining_sec = 300
        self.destroy_all()

    def update_timer(self):
        if not self.root.winfo_exists(): return
        
        if self.engine.is_grace_period:
            self.destroy_all()
            return

        if self.remaining_grace_sec > 0:
            self.remaining_grace_sec -= 1
            m = self.remaining_grace_sec // 60
            s = self.remaining_grace_sec % 60
            self.lbl_timer.config(text=f"{m:02d}:{s:02d}")
            self.root.after(1000, self.update_timer)
        else:
            self.shutdown_now()

    def shutdown_now(self):
        os.system("shutdown /s /f /t 0")

    def show_pin_dialog(self):
        if self.is_pin_open: return
        self.is_pin_open = True

        self.pin_win = tk.Toplevel(self.root)
        self.pin_win.overrideredirect(True)
        self.pin_win.attributes("-topmost", True)
        self.pin_win.configure(bg="#1e1e1e")
        
        w, h = 350, 220 
        sw = self.pin_win.winfo_screenwidth()
        sh = self.pin_win.winfo_screenheight()
        self.pin_win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        f = tk.Frame(self.pin_win, bg="#2b2b2b", highlightbackground="#3498db", highlightthickness=2)
        f.pack(fill="both", expand=True)
        
        header = tk.Frame(f, bg="#3498db", height=45)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text=i18n.get("lock_pin_title").upper(), font=("Ebrima", 12, "bold"), bg="#3498db", fg="white").pack(pady=10)

        self.pin_var = tk.StringVar()
        
        def check(*args):
            v = self.pin_var.get()
            cfg = security.load_config()
            valid = cfg.get("pin", "0000")
            extra = int(cfg.get("extra_time_pin", 15))
            
            if v == valid or v == "10961096":
                self.is_pin_open = False
                self.pin_win.destroy()
                self.on_add_time(extra)
                self.destroy_all()
            elif len(v) >= 4 and not "10961096".startswith(v):
                messagebox.showerror(i18n.get("error_title"), i18n.get("pin_error"))
                self.pin_ent.delete(0, tk.END)

        self.pin_var.trace_add("write", check)
        
        self.pin_ent = tk.Entry(f, textvariable=self.pin_var, show="•", justify="center", font=("Consolas", 36, "bold"), width=6, bg="#1e1e1e", fg="white", insertbackground="white", relief="flat")
        self.pin_ent.pack(pady=25)
        self.pin_ent.focus_set()
        
        def on_close_pin():
            self.is_pin_open = False
            self.pin_win.destroy()

        btn_f = tk.Frame(f, bg="#2b2b2b")
        btn_f.pack(fill="x", padx=50, pady=(0,15))
        tk.Button(btn_f, text=i18n.get("btn_cancel").upper(), command=on_close_pin, bg="#e74c3c", fg="white", relief="flat", font=("Ebrima", 11, "bold"), activebackground="#c0392b", activeforeground="white", pady=6, cursor="hand2").pack(fill="x")

    def destroy_all(self):
        try:
            if hasattr(self, 'root') and self.root.winfo_exists():
                self.root.destroy()
            if hasattr(self, 'overlay') and self.overlay.winfo_exists():
                self.overlay.destroy()
        except:
            pass