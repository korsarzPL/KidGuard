import customtkinter as ctk
from tkinter import messagebox
import os
import sys
import webbrowser
import socket
import security
from i18n import i18n

class SetupWizard:
    def __init__(self):
        cfg = security.load_config()
        ctk.set_appearance_mode(cfg.get("theme", "Dark"))
        ctk.set_default_color_theme("blue")

        self.root = ctk.CTk()
        self.root.title("KidGuard Setup")
        self.root.geometry("650x850")
        self.root.resizable(False, False)
        
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"+{(sw-650)//2}+{(sh-850)//2}")
        
        self.font_header = ctk.CTkFont(family="Roboto", size=28, weight="bold")
        self.font_sub = ctk.CTkFont(family="Roboto", size=14)
        self.font_bold = ctk.CTkFont(family="Roboto", size=14, weight="bold")
        self.font_desc = ctk.CTkFont(family="Roboto", size=11)
        
        self.build_ui()
        self.update_texts()

    def get_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 1)); ip = s.getsockname()[0]; s.close()
            return ip
        except: return "127.0.0.1"

    def build_ui(self):
        self.header_lbl = ctk.CTkLabel(self.root, text="KidGuard", font=self.font_header, text_color=["#333", "#fff"])
        self.header_lbl.pack(pady=(30, 10))

        self.scroll = ctk.CTkScrollableFrame(self.root, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        self.desc_lbl = ctk.CTkLabel(self.scroll, text="", font=self.font_sub, wraplength=550, text_color="gray")
        self.desc_lbl.pack(pady=(0, 20))

        self.frame1 = ctk.CTkFrame(self.scroll, fg_color=["#e0e0e0", "#2b2b2b"], corner_radius=15)
        self.frame1.pack(fill="x", pady=10, ipady=10)

        self.lbl_lang = ctk.CTkLabel(self.frame1, text="", font=self.font_bold)
        self.lbl_lang.pack(anchor="w", padx=20, pady=(15, 0))
        self.lbl_lang_desc = ctk.CTkLabel(self.frame1, text="", font=self.font_desc, text_color="gray")
        self.lbl_lang_desc.pack(anchor="w", padx=20, pady=(0, 5))
        
        lang_files = [f.split('_')[1].split('.')[0] for f in os.listdir('.') if f.startswith('lang_') and f.endswith('.json')]
        if not lang_files: lang_files = ["pl"]
        default_lang = "en" if "en" in lang_files else ("pl" if "pl" in lang_files else lang_files[0])
        i18n.set_language(default_lang)

        self.lang_var = ctk.StringVar(value=default_lang)
        self.lang_combo = ctk.CTkComboBox(self.frame1, values=lang_files, variable=self.lang_var, command=self.on_lang_change, width=200, height=35)
        self.lang_combo.pack(anchor="w", padx=20, pady=(0, 15))

        self.lbl_pin = ctk.CTkLabel(self.frame1, text="", font=self.font_bold)
        self.lbl_pin.pack(anchor="w", padx=20, pady=(10, 0))
        self.lbl_pin_desc = ctk.CTkLabel(self.frame1, text="", font=self.font_desc, text_color="gray")
        self.lbl_pin_desc.pack(anchor="w", padx=20, pady=(0, 5))
        
        self.pin_entry = ctk.CTkEntry(self.frame1, placeholder_text="0000", width=200, height=40, font=self.font_header, show="*", justify="center")
        self.pin_entry.pack(anchor="w", padx=20, pady=(0, 15))

        self.frame3 = ctk.CTkFrame(self.scroll, fg_color=["#e0e0e0", "#2b2b2b"], corner_radius=15)
        self.frame3.pack(fill="x", pady=10, ipady=10)
        
        self.autostart_var = ctk.BooleanVar(value=True)
        self.autostart_switch = ctk.CTkSwitch(self.frame3, text="", variable=self.autostart_var, font=self.font_bold, button_color="#1f6aa5", progress_color="#1f6aa5")
        self.autostart_switch.pack(anchor="w", padx=20, pady=(15, 5))
        self.lbl_auto_desc = ctk.CTkLabel(self.frame3, text="", font=self.font_desc, text_color="gray", wraplength=550, justify="left")
        self.lbl_auto_desc.pack(anchor="w", padx=20, pady=(0, 10))

        self.frame4 = ctk.CTkFrame(self.scroll, fg_color=["#e0e0e0", "#2b2b2b"], corner_radius=15)
        self.frame4.pack(fill="x", pady=10, ipady=10)
        
        self.web_var = ctk.BooleanVar(value=False)
        self.web_switch = ctk.CTkSwitch(self.frame4, text="", variable=self.web_var, command=self.toggle_web, font=self.font_bold, button_color="#1f6aa5", progress_color="#1f6aa5")
        self.web_switch.pack(anchor="w", padx=20, pady=(15, 5))
        self.lbl_web_desc = ctk.CTkLabel(self.frame4, text="", font=self.font_desc, text_color="gray", wraplength=550, justify="left")
        self.lbl_web_desc.pack(anchor="w", padx=20, pady=(0, 10))

        self.web_info = ctk.CTkFrame(self.frame4, fg_color=["#fff", "#1a1a1a"], corner_radius=8)
        self.lbl_web_addr = ctk.CTkLabel(self.web_info, text="", font=self.font_sub, text_color="gray")
        self.lbl_web_addr.pack(anchor="w", padx=15, pady=(10, 0))
        self.lbl_ip = ctk.CTkLabel(self.web_info, text=f"http://{self.get_ip()}:8080", font=ctk.CTkFont(family="Roboto Mono", size=18, weight="bold"), text_color="#4a90e2")
        self.lbl_ip.pack(anchor="w", padx=15, pady=(0, 5))
        
        self.lbl_web_instr = ctk.CTkLabel(self.web_info, text=i18n.get("website_step_1") + "\n" + i18n.get("website_step_2") + "\n" + i18n.get("website_step_3"), 
                                          font=self.font_desc, text_color="gray", justify="left")
        self.lbl_web_instr.pack(anchor="w", padx=15, pady=(0, 10))

        self.btn_start = ctk.CTkButton(self.root, text="", font=self.font_bold, height=60, fg_color="#27ae60", hover_color="#219653", corner_radius=0, command=self.save_and_start)
        self.btn_start.pack(fill="x", side="bottom")

    def on_lang_change(self, value):
        i18n.set_language(value)
        self.update_texts()

    def toggle_web(self):
        if self.web_var.get(): self.web_info.pack(fill="x", padx=20, pady=10)
        else: self.web_info.pack_forget()

    def update_texts(self):
        self.header_lbl.configure(text=i18n.get("wizard_welcome"))
        self.desc_lbl.configure(text=i18n.get("wizard_desc"))
        self.lbl_lang.configure(text=i18n.get("wizard_lang"))
        self.lbl_lang_desc.configure(text=i18n.get("wizard_lang_desc"))
        self.lbl_pin.configure(text=i18n.get("wizard_pin"))
        self.lbl_pin_desc.configure(text=i18n.get("wizard_pin_desc"))
        self.autostart_switch.configure(text=i18n.get("wizard_autostart"))
        self.lbl_auto_desc.configure(text=i18n.get("wizard_autostart_desc"))
        self.web_switch.configure(text=i18n.get("website_friendly_enable"))
        self.lbl_web_desc.configure(text=i18n.get("website_friendly_desc"))
        self.lbl_web_addr.configure(text=i18n.get("website_address_label"))
        
        self.lbl_web_instr.configure(text=i18n.get("website_step_1") + "\n" + i18n.get("website_step_2") + "\n" + i18n.get("website_step_3"))

        self.btn_start.configure(text=i18n.get("wizard_btn_start"))

    def manage_autostart(self, enabled):
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        app_name = "KidGuard"
        
        if getattr(sys, 'frozen', False):
            exe_path = f'"{sys.executable}"'
        else:
            pythonw_path = sys.executable.replace("python.exe", "pythonw.exe")
            main_script = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "main.py")
            exe_path = f'"{pythonw_path}" "{main_script}"'
            
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
            if enabled: winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, exe_path)
            else:
                try: winreg.DeleteValue(key, app_name)
                except: pass
            winreg.CloseKey(key)
        except: pass

    def save_and_start(self):
        pin = self.pin_entry.get()
        if len(pin) < 4:
            messagebox.showerror(i18n.get("wizard_pin_error_title"), i18n.get("wizard_pin_error_msg"))
            return
            
        is_autostart = self.autostart_var.get()
        cfg = security.load_config()
        cfg.update({
            "lang": self.lang_var.get(),
            "pin": pin,
            "web_active": self.web_var.get(),
            "autostart": is_autostart,
            "extra_time_pin": "15",
            "show_blue_btn": True
        })
        
        security.save_config(cfg)
        self.manage_autostart(is_autostart)
        
        self.root.quit()
        self.root.destroy()