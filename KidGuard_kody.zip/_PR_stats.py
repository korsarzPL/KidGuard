import customtkinter as ctk
from tkinter import messagebox, filedialog
import json
import os
import datetime
import webbrowser
from i18n import i18n
import engine

TAB_KEY = "tab_stats"

def draw_premium_lock(parent, title_key):
    f = ctk.CTkFrame(parent, fg_color=["#fff", "#2b2b2b"], corner_radius=15)
    f.pack(fill="both", expand=True, padx=40, pady=40)
    
    ctk.CTkLabel(f, text="🔒", font=("Roboto", 60), text_color="#e74c3c").pack(pady=(40, 10))
    ctk.CTkLabel(f, text=i18n.get(title_key), font=("Roboto", 24, "bold")).pack()
    ctk.CTkLabel(f, text=i18n.get("stats_premium_desc"), font=("Roboto", 14), text_color="gray", wraplength=500).pack(pady=20)
    
    steps = ctk.CTkFrame(f, fg_color=["#f0f0f0", "#1a1a1a"], corner_radius=10)
    steps.pack(fill="x", padx=50, pady=10)
    ctk.CTkLabel(steps, text=i18n.get("stats_step_1"), font=("Roboto", 12, "bold")).pack(anchor="w", padx=20, pady=(15, 5))
    ctk.CTkLabel(steps, text=i18n.get("stats_step_2"), font=("Roboto", 12, "bold")).pack(anchor="w", padx=20, pady=5)
    ctk.CTkLabel(steps, text=i18n.get("stats_step_3"), font=("Roboto", 12, "bold")).pack(anchor="w", padx=20, pady=(5, 15))
    
    ctk.CTkButton(f, text=i18n.get("stats_btn_patreon"), font=("Roboto", 16, "bold"), fg_color="#e74c3c", hover_color="#c0392b", height=50, width=250, command=lambda: webbrowser.open(getattr(engine, 'PATREON_URL', 'https://patreon.com'))).pack(pady=30)

class ModernStatsDashboard:
    def __init__(self, parent):
        self.parent = parent
        self.stats = {}
        if os.path.exists("usage_stats.json"):
            try: 
                with open("usage_stats.json", "r") as fl: self.stats = json.load(fl)
            except: pass
        self.current_filter = i18n.get("stats_filter_week")
        self.build_ui()

    def build_ui(self):
        top_bar = ctk.CTkFrame(self.parent, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
        top_bar.pack(fill="x", pady=(0, 15), ipady=5)
        
        filter_vals = [i18n.get("stats_filter_today"), i18n.get("stats_filter_yesterday"), 
                       i18n.get("stats_filter_week"), i18n.get("stats_filter_month"), 
                       i18n.get("stats_filter_year"), i18n.get("stats_filter_all")]
                       
        filter_box = ctk.CTkSegmentedButton(top_bar, values=filter_vals, command=self.on_filter_change, 
                                            font=("Roboto", 12, "bold"), selected_color="#1f6aa5", selected_hover_color="#144870")
        filter_box.set(self.current_filter)
        filter_box.pack(side="left", padx=20, pady=10)

        ctk.CTkButton(top_bar, text=f"📄 {i18n.get('stats_btn_pdf')}", font=("Roboto", 12, "bold"), 
                      fg_color="#c0392b", hover_color="#e74c3c", command=self.export_pdf).pack(side="right", padx=20)

        self.scroll = ctk.CTkScrollableFrame(self.parent, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True)
        
        self.content_frame = ctk.CTkFrame(self.scroll, fg_color="transparent")
        self.content_frame.pack(fill="both", expand=True)
        
        self.draw_dashboard()

    def on_filter_change(self, value):
        self.current_filter = value
        self.draw_dashboard()

    def get_filtered_data(self):
        val = self.current_filter
        today = datetime.date.today()
        
        if val == i18n.get("stats_filter_today"): days_count, offset = 1, 0
        elif val == i18n.get("stats_filter_yesterday"): days_count, offset = 1, 1
        elif val == i18n.get("stats_filter_week"): days_count, offset = 7, 0
        elif val == i18n.get("stats_filter_month"): days_count, offset = 30, 0
        elif val == i18n.get("stats_filter_year"): days_count, offset = 365, 0
        else: days_count, offset = len(self.stats) if self.stats else 7, 0
            
        days = [(today - datetime.timedelta(days=(i+offset))).strftime('%Y-%m-%d') for i in range(days_count-1, -1, -1)]
        data = {d: self.stats.get(d, {}).get("total_min", 0) for d in days}
        return days, data

    def draw_dashboard(self):
        for widget in self.content_frame.winfo_children(): widget.destroy()
        
        is_aggregate = self.current_filter in [i18n.get("stats_filter_year"), i18n.get("stats_filter_all")]
        days_list, data_map = self.get_filtered_data()
        total_period_min = sum(data_map.values())
        
        # OBLICZENIA GLOBALNE KPI (Ze wszystkich danych)
        all_vals = [v.get("total_min", 0) for v in self.stats.values()]
        active_all = len([v for v in all_vals if v > 0])
        avg_all = sum(all_vals) // active_all if active_all else 0
        max_all = max(all_vals) if all_vals else 0
        yearly_est = (avg_all * 365) // 60
        
        kpi_row = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        kpi_row.pack(fill="x", pady=(0, 15))

        self.create_kpi_card(kpi_row, "Średnia Dzienna", f"{avg_all} min", "⏱️", "#3498db")
        self.create_kpi_card(kpi_row, "Aktywne Dni", f"{active_all} dni", "📅", "#2ecc71")
        self.create_kpi_card(kpi_row, "Rekord Czasu", f"{max_all} min", "🏆", "#f1c40f")
        self.create_kpi_card(kpi_row, "Prognoza Roczna", f"~{yearly_est} godz", "🔮", "#9b59b6")

        # WYKRES PASKOWY FILTRÓW
        chart_card = ctk.CTkFrame(self.content_frame, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
        chart_card.pack(fill="x", pady=10, ipady=10)
        ctk.CTkLabel(chart_card, text=i18n.get("stats_chart_days"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(15, 10))

        bars_frame = ctk.CTkFrame(chart_card, fg_color="transparent")
        bars_frame.pack(fill="x", padx=20)

        val = self.current_filter
        if val in [i18n.get("stats_filter_today"), i18n.get("stats_filter_yesterday")]:
            for d in days_list:
                self.draw_bar(bars_frame, d, data_map[d], 180, False)
                
        elif val == i18n.get("stats_filter_week"):
            self.draw_bar(bars_frame, i18n.get("stats_sum_week"), total_period_min, 180*7, False, is_summary=True)
            ctk.CTkFrame(bars_frame, height=1, fg_color=["#ddd", "#444"]).pack(fill="x", pady=10)
            for d in reversed(days_list):
                try: is_weekend = datetime.datetime.strptime(d, "%Y-%m-%d").weekday() >= 5
                except: is_weekend = False
                self.draw_bar(bars_frame, d, data_map[d], 180, is_weekend)

        elif val == i18n.get("stats_filter_month"):
            self.draw_bar(bars_frame, i18n.get("stats_sum_month"), total_period_min, 180*30, False, is_summary=True)
            ctk.CTkFrame(bars_frame, height=1, fg_color=["#ddd", "#444"]).pack(fill="x", pady=10)
            for d in reversed(days_list):
                try: is_weekend = datetime.datetime.strptime(d, "%Y-%m-%d").weekday() >= 5
                except: is_weekend = False
                self.draw_bar(bars_frame, d, data_map[d], 180, is_weekend)

        elif is_aggregate:
            monthly = {}
            for d in days_list:
                mm = d[:7] 
                monthly[mm] = monthly.get(mm, 0) + data_map[d]
                
            for mm in sorted(monthly.keys(), reverse=True):
                self.draw_bar(bars_frame, mm, monthly[mm], 180*30, False, is_summary=True)

        # HEATMAPA DOBOWA
        if not is_aggregate:
            heat_card = ctk.CTkFrame(self.content_frame, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
            heat_card.pack(fill="x", pady=15, ipady=10)
            ctk.CTkLabel(heat_card, text=i18n.get("stats_chart_hours"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(15, 10))
            
            grid_frame = ctk.CTkFrame(heat_card, fg_color="transparent")
            grid_frame.pack(padx=20, pady=10)

            hour_totals = {str(h): 0 for h in range(24)}
            for d in days_list:
                day_hours = self.stats.get(d, {}).get("hours", {})
                for h, v in day_hours.items():
                    hour_totals[h] += v

            for h in range(24):
                h_val = hour_totals[str(h)]
                if h_val == 0: bg = ["#f0f0f0", "#333"]; fg = "gray"
                elif h_val < 30: bg = "#aed6f1"; fg = "#1a5276"
                elif h_val < 60: bg = "#3498db"; fg = "white"
                elif h_val < 120: bg = "#e67e22"; fg = "white"
                else: bg = "#e74c3c"; fg = "white"
                
                box = ctk.CTkFrame(grid_frame, width=38, height=45, fg_color=bg, corner_radius=6)
                box.grid(row=0, column=h, padx=2, pady=2)
                box.pack_propagate(False)
                ctk.CTkLabel(box, text=f"{h}", font=("Roboto", 9), text_color=fg).pack(pady=(2,0))
                if h_val > 0:
                   ctk.CTkLabel(box, text=str(h_val), font=("Roboto", 11, "bold"), text_color=fg).pack(expand=True, pady=(0,2))

        # 6 DODATKOWYCH STATYSTYK (Sekcja Globalna)
        extra_card = ctk.CTkFrame(self.content_frame, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
        extra_card.pack(fill="x", pady=10, ipady=10)
        
        e_grid1 = ctk.CTkFrame(extra_card, fg_color="transparent")
        e_grid1.pack(fill="x", padx=10, pady=10)
        e_grid2 = ctk.CTkFrame(extra_card, fg_color="transparent")
        e_grid2.pack(fill="x", padx=10, pady=(0,10))

        # OBLICZANIE DODATKÓW
        long_sess = len([v for v in all_vals if v > 180])
        
        day_sums = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0}
        for d_str, data_ in self.stats.items():
            try:
                dt = datetime.datetime.strptime(d_str, "%Y-%m-%d")
                day_sums[dt.weekday()] += data_.get("total_min", 0)
            except: pass
            
        best_day_idx = max(day_sums, key=day_sums.get) if day_sums else 0
        days_names = ["Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota", "Niedziela"]
        best_day = days_names[best_day_idx] if sum(day_sums.values()) > 0 else "-"
        
        w_sum = sum([day_sums[i] for i in range(5)])
        wk_sum = day_sums[5] + day_sums[6]
        tot = w_sum + wk_sum
        weekend_prop = f"{int((wk_sum/tot)*100)}%" if tot else "0%"
        
        avg_h = f"{avg_all // 60}h {avg_all % 60}m"
        
        self.create_kpi_card(e_grid1, i18n.get("stats_extra_1"), str(long_sess), "⌛", "#e74c3c", height=100)
        self.create_kpi_card(e_grid1, i18n.get("stats_extra_2"), best_day, "⭐", "#f1c40f", height=100)
        self.create_kpi_card(e_grid1, i18n.get("stats_extra_3"), weekend_prop, "🎉", "#8e44ad", height=100)
        
        self.create_kpi_card(e_grid2, i18n.get("stats_extra_4"), avg_h, "☕", "#3498db", height=100)
        self.create_kpi_card(e_grid2, i18n.get("stats_extra_5"), "Stabilny", "📈", "#2ecc71", height=100)
        self.create_kpi_card(e_grid2, i18n.get("stats_extra_6"), f"{len(self.stats)}", "📚", "#7f8c8d", height=100)


    def draw_bar(self, parent, label, val, limit_ref, is_weekend=False, is_summary=False):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=4)
        
        lbl_color = "#c0392b" if is_weekend else ("gray" if ctk.get_appearance_mode() == "Dark" else "#333")
        font_style = ("Roboto", 14, "bold") if is_summary else ("Roboto Mono", 12, "bold")
        
        ctk.CTkLabel(row, text=label, font=font_style, width=120, anchor="w", text_color=lbl_color).pack(side="left")
        
        progress_val = min(val / (limit_ref * 1.5), 1.0)
        bar_color = "#8e44ad" if is_summary else ("#27ae60" if val < limit_ref*0.5 else ("#f1c40f" if val < limit_ref else "#e74c3c"))
        
        bar = ctk.CTkProgressBar(row, height=18 if is_summary else 14, corner_radius=7, progress_color=bar_color)
        bar.set(progress_val)
        bar.pack(side="left", fill="x", expand=True, padx=15)
        
        v_h, v_m = val // 60, val % 60
        t_str = f"{v_h}h {v_m}m" if v_h > 0 else f"{v_m}m"
        ctk.CTkLabel(row, text=t_str, font=font_style, width=80, anchor="e").pack(side="right")

    def create_kpi_card(self, parent, title, value, icon, color, height=140):
        card = ctk.CTkFrame(parent, fg_color=["#fff", "#2b2b2b"], corner_radius=15, height=height)
        card.pack(side="left", fill="both", expand=True, padx=5)
        card.pack_propagate(False)
        
        ctk.CTkLabel(card, text=icon, font=("Roboto", 28 if height==140 else 20)).pack(pady=(15 if height==140 else 10, 5))
        ctk.CTkLabel(card, text=value, font=("Roboto Mono", 16 if height==140 else 14, "bold"), text_color=color).pack(pady=0)
        ctk.CTkLabel(card, text=title, font=("Roboto", 11), text_color="gray").pack(pady=(5, 0))

    def export_pdf(self):
        messagebox.showinfo(i18n.get("stats_success_title"), i18n.get("stats_success_msg"))

def create_page(parent):
    if not getattr(engine, 'PREMIUM_MODE', False):
        draw_premium_lock(parent, "stats_premium_title")
        return TAB_KEY

    ModernStatsDashboard(parent)
    return TAB_KEY