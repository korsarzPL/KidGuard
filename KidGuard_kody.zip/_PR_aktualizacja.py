import urllib.request
import os
import sys
import zipfile
import json
from i18n import i18n
import engine

TAB_KEY = "tab_about"

UPDATER_ZIP_URL = "https://raw.githubusercontent.com/korsarzPL/KidGuard/main/updater.zip"


def create_page(parent):
    # zostawiam, jeśli gdzieś używasz w UI – ale bez logiki aktualizacji
    import customtkinter as ctk

    container = ctk.CTkFrame(parent, fg_color="transparent")
    container.pack(fill="both", expand=True, padx=20, pady=20)

    card = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=15)
    card.pack(fill="x", pady=10, ipady=15)

    ctk.CTkLabel(card, text="KidGuard", font=("Roboto", 24, "bold"), text_color="#38bdf8").pack(pady=(20, 5))
    ctk.CTkLabel(card, text="System Kontroli Rodzicielskiej", font=("Roboto", 14), text_color="gray").pack(pady=(0, 20))
    ctk.CTkLabel(card, text=i18n.get("tab_about_desc"), font=("Roboto", 12), justify="center").pack(pady=10)

    current_version = getattr(engine.engine, 'app_version', "1.0.0")
    is_premium = getattr(engine.engine, 'is_premium', False)

    status_premium = "TAK (Aktywne)" if is_premium else "NIE (Wersja Podstawowa)"
    color_premium = "#10b981" if is_premium else "#e74c3c"

    info_frame = ctk.CTkFrame(card, fg_color="transparent")
    info_frame.pack(pady=15)

    ctk.CTkLabel(info_frame, text=f"Zainstalowana wersja: v{current_version}", font=("Roboto", 13, "bold"), text_color="#facc15").pack(pady=2)

    prem_frame = ctk.CTkFrame(info_frame, fg_color="transparent")
    prem_frame.pack(pady=2)
    ctk.CTkLabel(prem_frame, text="Status licencji Premium: ", font=("Roboto", 13, "bold")).pack(side="left")
    ctk.CTkLabel(prem_frame, text=status_premium, font=("Roboto", 13, "bold"), text_color=color_premium).pack(side="left")


def perform_update(kidguard_zip_url, hard_reset, new_version):
    """Pobiera updater.zip, wypakowuje updater.exe, uruchamia go i kończy proces."""
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))

    updater_zip = os.path.join(base_dir, "updater.zip")
    updater_exe = os.path.join(base_dir, "updater.exe")

    # pobierz updater.zip
    try:
        urllib.request.urlretrieve(UPDATER_ZIP_URL, updater_zip)
    except Exception as e:
        print("Error downloading updater.zip:", e)
        return

    # wypakuj updater.exe
    try:
        with zipfile.ZipFile(updater_zip, "r") as zip_ref:
            zip_ref.extractall(base_dir)
    except Exception as e:
        print("Error extracting updater.zip:", e)
        return
    finally:
        try:
            os.remove(updater_zip)
        except:
            pass

    if not os.path.exists(updater_exe):
        print("updater.exe not found after extraction.")
        return

    exe_path = os.path.abspath(sys.executable)
    hr_flag = "1" if hard_reset else "0"

    import subprocess
    subprocess.Popen([
        updater_exe,
        exe_path,
        kidguard_zip_url,
        new_version,
        hr_flag
    ])

    os._exit(0)
