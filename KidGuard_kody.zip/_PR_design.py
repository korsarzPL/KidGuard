import customtkinter as ctk
import os
import engine
import security
from i18n import i18n
from tkinter import filedialog, colorchooser
from PIL import Image, ImageTk

TAB_KEY = "tab_design"

# Globalny słownik, aby funkcja save_trigger widziała zmienne!
ui_vars = {}

class ImageCropper(ctk.CTkToplevel):
    def __init__(self, master, image_path, target_w, target_h, on_crop_callback):
        super().__init__(master)
        self.title(i18n.get("crop_title"))
        self.target_w = target_w
        self.target_h = target_h
        self.callback = on_crop_callback
        
        self.geometry("800x600")
        self.attributes("-topmost", True)
        self.lift()
        self.focus_force()

        self.original_img = Image.open(image_path)
        self.scale_ratio = 1.0
        self.rect_x = 50
        self.rect_y = 50

        self.setup_ui()
        self.update_canvas()

    def setup_ui(self):
        self.canvas = ctk.CTkCanvas(self, bg="#222", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<Button-1>", self.on_click)

        bot = ctk.CTkFrame(self, fg_color="transparent")
        bot.pack(fill="x", padx=10, pady=10)
        
        self.zoom_var = ctk.DoubleVar(value=1.0)
        zoom_slider = ctk.CTkSlider(bot, from_=0.1, to=3.0, variable=self.zoom_var, command=self.on_zoom)
        zoom_slider.pack(side="left", fill="x", expand=True, padx=20)
        
        ctk.CTkButton(bot, text=i18n.get("crop_btn_save"), fg_color="#27ae60", hover_color="#219653", command=self.save_crop).pack(side="right")

    def on_zoom(self, val):
        self.scale_ratio = float(val)
        self.update_canvas()

    def update_canvas(self):
        self.canvas.delete("all")
        
        new_w = int(self.original_img.width * self.scale_ratio)
        new_h = int(self.original_img.height * self.scale_ratio)
        resized = self.original_img.resize((new_w, new_h), Image.LANCZOS)
        self.tk_img = ImageTk.PhotoImage(resized)
        
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_img)
        
        rw = self.target_w
        rh = self.target_h
        x1, y1 = self.rect_x, self.rect_y
        x2, y2 = x1 + rw, y1 + rh
        
        self.canvas.create_rectangle(0, 0, new_w, y1, fill="#000", stipple="gray50", outline="")
        self.canvas.create_rectangle(0, y2, new_w, new_h, fill="#000", stipple="gray50", outline="")
        self.canvas.create_rectangle(0, y1, x1, y2, fill="#000", stipple="gray50", outline="")
        self.canvas.create_rectangle(x2, y1, new_w, y2, fill="#000", stipple="gray50", outline="")
        
        self.canvas.create_rectangle(x1, y1, x2, y2, outline="#e74c3c", width=3, tags="crop_box")

    def on_click(self, event):
        self.start_x = event.x
        self.start_y = event.y

    def on_drag(self, event):
        dx = event.x - self.start_x
        dy = event.y - self.start_y
        self.rect_x += dx
        self.rect_y += dy
        self.start_x = event.x
        self.start_y = event.y
        self.update_canvas()

    def save_crop(self):
        left = int(self.rect_x / self.scale_ratio)
        top = int(self.rect_y / self.scale_ratio)
        right = int((self.rect_x + self.target_w) / self.scale_ratio)
        bottom = int((self.rect_y + self.target_h) / self.scale_ratio)
        
        cropped = self.original_img.crop((left, top, right, bottom))
        out_path = "custom_bg_cropped.png"
        cropped.save(out_path)
        
        self.callback(out_path)
        self.destroy()

def create_page(parent):
    if not getattr(engine, 'PREMIUM_MODE', False):
        import _PR_stats
        _PR_stats.draw_premium_lock(parent, "design_title")
        return TAB_KEY

    try:
        cfg = security.load_config()
    except:
        cfg = {}
        
    design_cfg = cfg.get("design", {})
    
    base_w = 210
    sw = parent.winfo_screenwidth()
    max_pos = sw - base_w
    default_pos = max_pos // 2

    ui_vars["pos_x"] = ctk.DoubleVar(value=float(design_cfg.get("pos_x", default_pos)))
    ui_vars["alpha"] = ctk.DoubleVar(value=float(design_cfg.get("alpha", 0.8)))
    ui_vars["scale"] = ctk.DoubleVar(value=float(design_cfg.get("scale", 1.0)))
    ui_vars["font"] = ctk.StringVar(value=design_cfg.get("font", "Ebrima"))
    ui_vars["bg"] = ctk.StringVar(value=design_cfg.get("bg", ""))
    ui_vars["bg_color"] = ctk.StringVar(value=design_cfg.get("bg_color", "black"))

    def notify_app(*args):
        scaled_w = int(base_w * ui_vars["scale"].get())
        current_max = sw - scaled_w
        if ui_vars["pos_x"].get() > current_max: ui_vars["pos_x"].set(current_max)
        
        d = {
            "pos_x": int(ui_vars["pos_x"].get()),
            "alpha": float(ui_vars["alpha"].get()),
            "scale": float(ui_vars["scale"].get()),
            "font": ui_vars["font"].get(),
            "bg": ui_vars["bg"].get(),
            "bg_color": ui_vars["bg_color"].get()
        }
        app = getattr(engine.engine, 'counter_app', None)
        if app: app.dynamic_update_design(d)

    def restore_defaults():
        ui_vars["pos_x"].set(default_pos)
        ui_vars["alpha"].set(0.8)
        ui_vars["scale"].set(1.0)
        ui_vars["font"].set("Ebrima")
        ui_vars["bg"].set("")
        ui_vars["bg_color"].set("black")
        
        slider_pos.configure(to=max_pos)
        notify_app()

    container = ctk.CTkScrollableFrame(parent, fg_color="transparent")
    container.pack(fill="both", expand=True)

    header = ctk.CTkFrame(container, fg_color=["#1f6aa5", "#144870"], corner_radius=10)
    header.pack(fill="x", pady=(0, 15), ipady=10)
    
    h_top = ctk.CTkFrame(header, fg_color="transparent")
    h_top.pack(fill="x", padx=20, pady=(10,0))
    
    ctk.CTkLabel(h_top, text=i18n.get("design_title"), font=("Roboto", 18, "bold"), text_color="white").pack(side="left")
    ctk.CTkButton(h_top, text=i18n.get("btn_restore_defaults"), fg_color="#e67e22", hover_color="#d35400", command=restore_defaults).pack(side="right")
    
    ctk.CTkLabel(header, text=i18n.get("design_desc"), font=("Roboto", 12), text_color="#a9d0f5").pack(anchor="w", padx=20)

    def build_slider(label, variable, from_, to, steps=0):
        row = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
        row.pack(fill="x", pady=5, ipady=10)
        
        lbl = ctk.CTkLabel(row, text=i18n.get(label), font=("Roboto", 14, "bold"))
        lbl.pack(anchor="w", padx=20, pady=(5,0))
        
        slider = ctk.CTkSlider(row, from_=from_, to=to, variable=variable, command=notify_app, progress_color="#e74c3c", button_color="#e74c3c")
        if steps > 0: slider.configure(number_of_steps=steps)
        slider.pack(fill="x", padx=20, pady=10)
        return slider

    slider_pos = build_slider("design_pos", ui_vars["pos_x"], 0, max_pos)
    
    def on_scale_change(val):
        scaled_w = int(base_w * float(val))
        new_max = sw - scaled_w
        slider_pos.configure(to=new_max)
        notify_app()
        
    build_slider("design_alpha", ui_vars["alpha"], 0.2, 1.0)
    
    row_scale = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    row_scale.pack(fill="x", pady=5, ipady=10)
    ctk.CTkLabel(row_scale, text=i18n.get("design_scale"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(5,0))
    ctk.CTkSlider(row_scale, from_=0.8, to=3.0, variable=ui_vars["scale"], command=on_scale_change, progress_color="#e74c3c", button_color="#e74c3c").pack(fill="x", padx=20, pady=10)

    font_row = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    font_row.pack(fill="x", pady=5, ipady=10)
    ctk.CTkLabel(font_row, text=i18n.get("design_font"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(10, 5))
    
    fonts = ["Ebrima", "Segoe UI", "Calibri", "Arial", "Consolas", "Courier New", "Tahoma", "Verdana", "Impact", "Comic Sans MS", "Trebuchet MS"]
    ui_vars["font"].trace_add("write", notify_app)
    ctk.CTkComboBox(font_row, values=fonts, variable=ui_vars["font"], font=("Roboto", 14), width=250).pack(anchor="w", padx=20)

    color_row = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    color_row.pack(fill="x", pady=5, ipady=10)
    ctk.CTkLabel(color_row, text=i18n.get("design_bg_color"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(10, 5))
    
    def pick_color():
        color_code = colorchooser.askcolor(title=i18n.get("btn_pick_color"))[1]
        if color_code:
            ui_vars["bg_color"].set(color_code)
            notify_app()
            
    c_sub = ctk.CTkFrame(color_row, fg_color="transparent")
    c_sub.pack(fill="x", padx=20)
    ctk.CTkEntry(c_sub, textvariable=ui_vars["bg_color"], width=150).pack(side="left")
    ctk.CTkButton(c_sub, text=i18n.get("btn_pick_color"), command=pick_color, fg_color="#9b59b6", width=120).pack(side="left", padx=10)

    bg_row = ctk.CTkFrame(container, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    bg_row.pack(fill="x", pady=5, ipady=10)
    ctk.CTkLabel(bg_row, text=i18n.get("design_bg"), font=("Roboto", 14, "bold")).pack(anchor="w", padx=20, pady=(10, 5))
    
    bg_sub = ctk.CTkFrame(bg_row, fg_color="transparent")
    bg_sub.pack(fill="x", padx=20)
    
    bg_entry = ctk.CTkEntry(bg_sub, textvariable=ui_vars["bg"], width=280)
    bg_entry.pack(side="left")
    
    def apply_cropped(path):
        ui_vars["bg"].set(path)
        notify_app()

    def pick_file():
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg")])
        if path:
            target_w = int(base_w * ui_vars["scale"].get())
            target_h = int(45 * ui_vars["scale"].get())
            ImageCropper(parent, path, target_w, target_h, apply_cropped)
            
    def clear_bg():
        ui_vars["bg"].set("")
        notify_app()
            
    ctk.CTkButton(bg_sub, text=i18n.get("btn_browse"), command=pick_file, fg_color="#3498db", width=90).pack(side="left", padx=(10, 5))
    ctk.CTkButton(bg_sub, text=i18n.get("btn_clear_bg"), command=clear_bg, fg_color="#e74c3c", width=90).pack(side="left")
    
    return TAB_KEY

# TO JEST FUNKCJA KTÓREJ SZUKA GŁÓWNE OKNO WTYCZEK, ABY ZAPISAĆ ZMIANY!
def save_trigger():
    if not ui_vars: return
    try:
        c = security.load_config()
        c["design"] = {
            "pos_x": int(ui_vars["pos_x"].get()),
            "alpha": float(ui_vars["alpha"].get()),
            "scale": float(ui_vars["scale"].get()),
            "font": ui_vars["font"].get(),
            "bg": ui_vars["bg"].get(),
            "bg_color": ui_vars["bg_color"].get()
        }
        security.save_config(c)
    except Exception as e:
        print("Zapis designu błąd:", e)