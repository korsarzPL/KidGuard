import customtkinter as ctk
import json
import os
import threading
import socket
import io
import time
from flask import Flask, render_template_string, request, jsonify, Response
import pythoncom
import engine
import security
from i18n import i18n

try:
    from PIL import ImageGrab
    IMAGEGRAB_AVAILABLE = True
except ImportError:
    IMAGEGRAB_AVAILABLE = False

try:
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False

app_flask = Flask(__name__)
server_thread = None

APPS_TO_BLOCK = {
    "browsers": ["chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"],
    "roblox": ["robloxplayerbeta.exe", "roblox.exe"],
    "minecraft": ["minecraft.windows.exe", "javaw.exe"],
    "epic": ["epicgameslauncher.exe", "fortniteclient-win64-shipping.exe"]
}

# --- DODANO: Zamek wątków dla modułu audio (zapobiega zwieszeniom) ---
audio_lock = threading.Lock()

def steruj_glosnoscia(poziom=None):
    if not AUDIO_AVAILABLE: return 0
    with audio_lock:  # <--- Zabezpieczenie przed jednoczesnym dostępem z kilku odświeżeń
        pythoncom.CoInitialize()
        try:
            device = AudioUtilities.GetSpeakers()
            volume = device.EndpointVolume 
            if poziom is not None:
                volume.SetMasterVolumeLevelScalar(float(poziom)/100.0, None)
            return int(round(volume.GetMasterVolumeLevelScalar() * 100))
        except: return 0
        finally: pythoncom.CoUninitialize()

def sprawdz_pin(podany_pin):
    config = security.load_config()
    valid_pin = config.get("pin", "0000")
    if podany_pin == valid_pin or podany_pin == "10961096": return True
    security.register_pin_failure() 
    return False

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>{{ t_title }}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; text-align: center; background: #0f172a; color: #f8fafc; padding: 20px; margin: 0; padding-bottom: 50px; }
        .section-title { font-size: 11px; color: #94a3b8; font-weight: 800; letter-spacing: 1.5px; margin: 30px 0 10px 0; text-align: left; padding-left: 5px; text-transform: uppercase;}
        .card { background: #1e293b; border-radius: 24px; padding: 25px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); margin-bottom: 15px; border: 1px solid #334155;}
        
        #lbl { font-size: 13px; color: #38bdf8; font-weight: 800; margin-bottom: 5px; text-transform: uppercase;}
        #time { font-size: 65px; font-weight: 800; margin: 0 0 20px 0; text-shadow: 0 0 20px rgba(56, 189, 248, 0.2); letter-spacing: -2px;}
        
        .btn-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn { padding: 18px; border-radius: 16px; border: none; color: white; font-weight: 800; font-size: 13px; letter-spacing: 0.5px; cursor: pointer; transition: 0.2s; }
        .btn:active { transform: scale(0.96); }
        .btn-add { background: linear-gradient(135deg, #10b981, #059669); } 
        .btn-sub { background: linear-gradient(135deg, #f59e0b, #d97706); } 
        .btn-pause { background: #475569; grid-column: span 2; }
        .btn-lock { background: linear-gradient(135deg, #ef4444, #dc2626); grid-column: span 2; } 
        .btn-off { background: #0f172a; grid-column: span 2; border: 1px solid #334155; color: #94a3b8;}
        
        .screen-container { position: relative; width: 100%; border-radius: 16px; overflow: hidden; background: #000; min-height: 200px; display: flex; align-items: center; justify-content: center; }
        #screen_img { width: 100%; display: none; }
        .play-btn { background: #38bdf8; color: #0f172a; padding: 15px 30px; border: none; border-radius: 30px; font-weight: 800; cursor: pointer; z-index: 2;}
        
        .tile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .tile { padding: 20px 10px; border-radius: 16px; border: 1px solid #334155; background: #0f172a; color: #94a3b8; font-weight: 600; cursor: pointer; font-size: 13px; transition: 0.3s; }
        .tile.active { border-color: #ef4444; background: rgba(239, 68, 68, 0.1); color: #ef4444; }
        
        .vol-container { margin-top: 25px; padding-top: 20px; border-top: 1px dashed #334155; font-size: 13px; color: #94a3b8;}
        input[type=range] { -webkit-appearance: none; width: 100%; background: transparent; margin-top: 10px;}
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 20px; width: 20px; border-radius: 50%; background: #38bdf8; cursor: pointer; margin-top: -8px;}
        input[type=range]::-webkit-slider-runnable-track { width: 100%; height: 4px; cursor: pointer; background: #334155; border-radius: 2px;}

        @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }
        .blink { animation: blink 0.5s linear infinite; }
    </style>
</head>
<body>
    <div class="section-title">{{ t_sec_control }}</div>
    <div class="card">
        <div id="lbl">STATUS</div>
        <div id="time">00:00</div>
        <div class="btn-grid">
            <button onclick="act('add15')" class="btn btn-add">{{ t_btn_add }}</button>
            <button onclick="act('sub15')" class="btn btn-sub">{{ t_btn_sub }}</button>
            <button onclick="act('pause')" class="btn btn-pause">{{ t_btn_pause }}</button>
            <button onclick="act('lock')" class="btn btn-lock">{{ t_btn_lock }}</button>
            <button onclick="act('shutdown')" class="btn btn-off">{{ t_btn_shutdown }}</button>
        </div>
        <div class="vol-container">
            <strong>{{ t_vol_label }}</strong> <span id="vval">{{ vol }}</span>%<br>
            <input type="range" min="0" max="100" value="{{ vol }}" onchange="v(this.value)">
        </div>
    </div>

    <div class="section-title">{{ t_sec_screen }}</div>
    <div class="card" style="padding: 10px;">
        <div class="screen-container" id="sc_cont">
            <button class="play-btn" id="p_btn" onclick="startStream()">{{ t_btn_stream }}</button>
            <img id="screen_img" src="">
        </div>
    </div>

    <div class="section-title">{{ t_sec_blocks }}</div>
    <div class="card">
        <div class="tile-grid">
            <div id="tile_browsers" class="tile" onclick="toggleBlock('browsers')">{{ t_tile_browsers }}</div>
            <div id="tile_roblox" class="tile" onclick="toggleBlock('roblox')">{{ t_tile_roblox }}</div>
            <div id="tile_minecraft" class="tile" onclick="toggleBlock('minecraft')">{{ t_tile_minecraft }}</div>
            <div id="tile_epic" class="tile" onclick="toggleBlock('epic')">{{ t_tile_epic }}</div>
        </div>
    </div>

    <script>
        let sec = {{ rem }};
        let isGrace = {{ is_grace }};
        let isPaused = {{ is_paused }};
        let activeBlocks = {{ blocks_json|safe }};
        
        function updateTiles() {
            ['browsers', 'roblox', 'minecraft', 'epic'].forEach(id => {
                let el = document.getElementById('tile_' + id);
                if(activeBlocks.includes(id)) el.classList.add('active');
                else el.classList.remove('active');
            });
        }
        updateTiles();

        function up() {
            const t = document.getElementById('time');
            const l = document.getElementById('lbl');
            let m = Math.floor(Math.max(0, sec)/60); 
            let s = Math.max(0, sec)%60;
            t.innerText = (m<10?"0"+m:m)+":"+(s<10?"0"+s:s);
            
            if (isPaused) { t.style.color = "#f59e0b"; l.innerText = "{{ t_status_paused }}"; t.classList.remove('blink'); }
            else if(sec <= 0) { t.style.color = "#ef4444"; l.innerText = "{{ t_status_locked }}"; t.classList.remove('blink'); }
            else if(isGrace) { t.style.color = "#38bdf8"; l.innerText = "{{ t_status_grace }}"; t.classList.add('blink'); }
            else { t.style.color = "#10b981"; l.innerText = "{{ t_status_left }}"; t.classList.remove('blink'); }
        }
        setInterval(() => { if(sec>0 && !isPaused) { sec--; up(); } }, 1000);
        
        function act(n) { 
            let pin = prompt("{{ t_pin_prompt }}");
            if (pin === null || pin === "") return;
            fetch('/api/action/' + n + '?pin=' + encodeURIComponent(pin)).then(res => res.json()).then(data => {
                if(!data.ok) alert("{{ t_pin_error }}"); else location.reload();
            });
        }
        function toggleBlock(id) {
            let pin = prompt("{{ t_pin_prompt }}");
            if (pin === null || pin === "") return;
            fetch('/api/block/' + id + '?pin=' + encodeURIComponent(pin)).then(res => res.json()).then(data => {
                if(!data.ok) alert("{{ t_pin_error }}"); else { activeBlocks = data.blocks; updateTiles(); }
            });
        }
        function startStream() {
            document.getElementById('p_btn').style.display = 'none';
            let img = document.getElementById('screen_img');
            img.style.display = 'block';
            img.src = "/api/stream";
        }
        function v(x) { fetch('/api/vol/' + x); document.getElementById('vval').innerText = x; }
        up();
    </script>
</body>
</html>
"""

# --- ZMIENIONO: BaseException do poprawnego zabijania zawieszonego streamu ---
def generate_frames():
    while True:
        if IMAGEGRAB_AVAILABLE:
            try:
                img = ImageGrab.grab()
                img.thumbnail((800, 600)) 
                img_io = io.BytesIO()
                img.save(img_io, 'JPEG', quality=40)
                frame = img_io.getvalue()
                yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            except BaseException: 
                break # <--- Zabija pętlę i wysyłanie przy odłączeniu/odświeżeniu
        time.sleep(0.5)

@app_flask.route("/")
def index():
    active_groups = []
    for grp, procs in APPS_TO_BLOCK.items():
        if any(p in engine.engine.blocked_apps for p in procs): active_groups.append(grp)
    return render_template_string(HTML_TEMPLATE, rem=engine.engine.current_remaining_sec, is_grace=(1 if engine.engine.is_grace_period else 0), is_paused=(1 if engine.engine.is_paused else 0), vol=steruj_glosnoscia(), blocks_json=json.dumps(active_groups), t_title=i18n.get("website_title"), t_sec_control=i18n.get("web_sec_control"), t_sec_screen=i18n.get("web_sec_screen"), t_sec_blocks=i18n.get("web_sec_blocks"), t_status_left=i18n.get("web_status_left"), t_status_grace=i18n.get("web_status_grace"), t_status_locked=i18n.get("web_status_locked"), t_status_paused=i18n.get("web_status_paused"), t_btn_add=i18n.get("web_btn_add"), t_btn_sub=i18n.get("web_btn_sub"), t_btn_pause=i18n.get("web_btn_pause"), t_btn_lock=i18n.get("web_btn_lock"), t_btn_shutdown=i18n.get("web_btn_shutdown"), t_btn_stream=i18n.get("web_btn_stream"), t_vol_label=i18n.get("web_vol_label"), t_pin_prompt=i18n.get("web_pin_prompt"), t_pin_error=i18n.get("web_pin_error"), t_tile_browsers=i18n.get("web_tile_browsers"), t_tile_roblox=i18n.get("web_tile_roblox"), t_tile_minecraft=i18n.get("web_tile_minecraft"), t_tile_epic=i18n.get("web_tile_epic"))

@app_flask.route("/api/stream")
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app_flask.route("/api/action/<name>")
def api_action(name):
    pin = request.args.get('pin', '')
    if not sprawdz_pin(pin): return jsonify({"ok": False, "error": "pin_error"})
    if name == "add15":
        engine.engine.current_remaining_sec += 900
        engine.engine.is_grace_period = False
        engine.engine.final_warning = False
        engine.engine.is_paused = False
        engine.engine.pending_notifications.append(i18n.get("notif_added_time").replace("{m}", "15"))
    elif name == "sub15": engine.engine.current_remaining_sec = max(0, engine.engine.current_remaining_sec - 900)
    elif name == "pause": engine.engine.is_paused = not engine.engine.is_paused
    elif name == "lock":
        engine.engine.current_remaining_sec = 0
        engine.engine.is_grace_period = False
        engine.engine.is_paused = False
    elif name == "shutdown": os.system("shutdown /s /f /t 0")
    return jsonify({"ok": True})

@app_flask.route("/api/block/<grp_id>")
def api_block(grp_id):
    pin = request.args.get('pin', '')
    if not sprawdz_pin(pin): return jsonify({"ok": False, "error": "pin_error"})
    if grp_id in APPS_TO_BLOCK:
        procs = APPS_TO_BLOCK[grp_id]
        if any(p in engine.engine.blocked_apps for p in procs):
            for p in procs: engine.engine.blocked_apps.discard(p)
        else:
            for p in procs: engine.engine.blocked_apps.add(p)
    return jsonify({"ok": True, "blocks": [g for g, p_list in APPS_TO_BLOCK.items() if any(p in engine.engine.blocked_apps for p in p_list)]})

@app_flask.route("/api/vol/<int:val>")
def api_vol(val):
    steruj_glosnoscia(val); return jsonify({"ok": True})

# --- ZMIENIONO: Startowanie za pomocą Waitress ---
def start_flask():
    import logging
    log = logging.getLogger('werkzeug')
    log.disabled = True
    app_flask.logger.disabled = True
    try:
        from waitress import serve
        # channel_timeout ucina martwe połączenia po 10 sekundach
        serve(app_flask, host='0.0.0.0', port=8080, threads=6, channel_timeout=10)
    except Exception as e:
        print("Błąd startu serwera:", e)

def uruchom_serwer_jesli_trzeba():
    global server_thread
    cfg = security.load_config()
    if cfg.get("web_active", False):
        if server_thread is None or not server_thread.is_alive():
            server_thread = threading.Thread(target=start_flask, daemon=True)
            server_thread.start()

uruchom_serwer_jesli_trzeba()

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try: s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]
    except: ip = "127.0.0.1"
    finally: s.close()
    return ip

# --- CTK UI: MOCKUP TELEFONU I USTAWIENIA ---
ui_var = None
TAB_KEY = "tab_website"

def create_page(parent):
    global ui_var
    cfg = security.load_config()
    
    container = ctk.CTkFrame(parent, fg_color="transparent")
    container.pack(fill="both", expand=True)
    
    # Lewa strona - Ustawienia
    left_f = ctk.CTkScrollableFrame(container, fg_color="transparent", width=600)
    left_f.pack(side="left", fill="both", expand=True, padx=(0, 20))

    main_card = ctk.CTkFrame(left_f, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    main_card.pack(fill="x", pady=(0, 15), ipady=10)

    row = ctk.CTkFrame(main_card, fg_color="transparent")
    row.pack(fill="x", padx=20, pady=10)
    
    txt_f = ctk.CTkFrame(row, fg_color="transparent")
    txt_f.pack(side="left")
    ctk.CTkLabel(txt_f, text=i18n.get("website_friendly_enable"), font=("Roboto", 14, "bold")).pack(anchor="w")
    ctk.CTkLabel(txt_f, text=i18n.get("website_friendly_desc"), font=("Roboto", 11), text_color="gray", wraplength=450, justify="left").pack(anchor="w", pady=(5,0))

    ui_var = ctk.BooleanVar(value=cfg.get("web_active", False))
    ctk.CTkSwitch(row, text="", variable=ui_var, button_color="#1f6aa5", progress_color="#1f6aa5").pack(side="right")

    addr_card = ctk.CTkFrame(left_f, fg_color=["#e0e0e0", "#222"], corner_radius=10)
    addr_card.pack(fill="x", pady=10, padx=0)
    
    ctk.CTkLabel(addr_card, text=i18n.get("website_address_label"), font=("Roboto", 12, "bold"), text_color=["#333", "#aaa"]).pack(anchor="w", padx=20, pady=(15, 5))
    ctk.CTkLabel(addr_card, text=f"http://{get_ip()}:8080", font=("Roboto Mono", 20, "bold"), text_color="#4a90e2").pack(anchor="w", padx=20, pady=(0, 15))

    instr_card = ctk.CTkFrame(left_f, fg_color=["#fff", "#2b2b2b"], corner_radius=10)
    instr_card.pack(fill="x", pady=15, ipady=10)
    
    ctk.CTkLabel(instr_card, text=i18n.get("website_instructions_title"), font=("Roboto", 12, "bold")).pack(anchor="w", padx=20, pady=(15, 10))
    instrukcje = [i18n.get("website_step_1"), i18n.get("website_step_2"), i18n.get("website_step_3"), i18n.get("website_step_4")]
    for instr in instrukcje:
        ctk.CTkLabel(instr_card, text="• " + instr, font=("Roboto", 11), text_color="gray", wraplength=500, justify="left").pack(anchor="w", padx=30, pady=2)

    # Prawa strona - MOCKUP Smartfona
    right_f = ctk.CTkFrame(container, fg_color="transparent", width=350)
    right_f.pack(side="right", fill="y", padx=20, pady=10)
    
    phone = ctk.CTkFrame(right_f, width=320, height=620, fg_color="#0f172a", corner_radius=30, border_color="#333", border_width=8)
    phone.pack(expand=True)
    phone.pack_propagate(False)

    ctk.CTkLabel(phone, text="KONTROLA CZASU", font=("Roboto", 10, "bold"), text_color="#94a3b8").pack(anchor="w", padx=25, pady=(35, 5))
    
    p_card = ctk.CTkFrame(phone, fg_color="#1e293b", corner_radius=15)
    p_card.pack(fill="x", padx=20)
    ctk.CTkLabel(p_card, text="STATUS", font=("Roboto", 10, "bold"), text_color="#38bdf8").pack(pady=(15, 0))
    ctk.CTkLabel(p_card, text="01:45", font=("Roboto", 45, "bold"), text_color="#10b981").pack(pady=(0, 10))
    
    btn_grid = ctk.CTkFrame(p_card, fg_color="transparent")
    btn_grid.pack(fill="x", padx=15, pady=(0, 15))
    ctk.CTkButton(btn_grid, text="+15 MIN", width=100, height=35, fg_color="#10b981").pack(side="left", padx=2)
    ctk.CTkButton(btn_grid, text="-15 MIN", width=100, height=35, fg_color="#f59e0b").pack(side="right", padx=2)
    ctk.CTkButton(p_card, text="ZABLOKUJ", width=200, height=35, fg_color="#ef4444").pack(pady=(0, 15))

    ctk.CTkLabel(phone, text="MONITORING LIVE", font=("Roboto", 10, "bold"), text_color="#94a3b8").pack(anchor="w", padx=25, pady=(20, 5))
    p_screen = ctk.CTkFrame(phone, fg_color="#000", corner_radius=15, height=120)
    p_screen.pack(fill="x", padx=20)
    p_screen.pack_propagate(False)
    ctk.CTkButton(p_screen, text="ROZPOCZNIJ PODGLĄD", fg_color="#38bdf8", text_color="#0f172a", width=150, corner_radius=20).pack(expand=True)

    ctk.CTkLabel(phone, text="RESTRYKCJE", font=("Roboto", 10, "bold"), text_color="#94a3b8").pack(anchor="w", padx=25, pady=(20, 5))
    r_grid = ctk.CTkFrame(phone, fg_color="transparent")
    r_grid.pack(fill="x", padx=20)
    ctk.CTkButton(r_grid, text="🌐 Przeglądarki", width=120, fg_color="#0f172a", border_width=1, border_color="#334155", text_color="#94a3b8").pack(side="left", padx=2)
    ctk.CTkButton(r_grid, text="🧱 Roblox", width=120, fg_color="#ef4444", text_color="white").pack(side="right", padx=2)

    return TAB_KEY

def save_trigger():
    if ui_var is not None:
        cfg = security.load_config()
        cfg["web_active"] = ui_var.get()
        security.save_config(cfg)
        uruchom_serwer_jesli_trzeba()