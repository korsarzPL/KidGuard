import json
import os

class I18nManager:
    def __init__(self, default_lang="pl"):
        self.current_lang = default_lang
        self.translations = {}
        self.languages = []
        self.load_available_languages()
        self.set_language(default_lang)

    def load_available_languages(self):
        # Szuka plików lang_*.json
        files = [f for f in os.listdir('.') if f.startswith('lang_') and f.endswith('.json')]
        self.languages = [f.split('_')[1].split('.')[0] for f in files]

    def set_language(self, lang_code):
        file_path = f"lang_{lang_code}.json"
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                self.translations = json.load(f)
                self.current_lang = lang_code
        else:
            # Jeśli nie ma wybranego, spróbuj załadować cokolwiek co jest dostępne
            if self.languages:
                self.set_language(self.languages[0])

    def get(self, key):
        return self.translations.get(key, key)

i18n = I18nManager()