import datetime
import json
import os
import security
import threading
import time
import psutil

# --- GLOBALNE ZMIENNE APLIKACJI ---
PREMIUM_MODE = True
PATREON_URL = "https://patreon.com/KidGuard" # Zmień na swój link docelowy
COFFEE_URL = "https://buymeacoffee.com/KidGuard" # Zmień na swój link docelowy

class Engine:
    def __init__(self):
        self.PLIK_LIMITOW = "limit_stan.json"
        self.PLIK_KALENDARZA = "calendar_overrides.json"
        self.PLIK_STANU = "daily_state.json"
        self.PLIK_STATYSTYK = "usage_stats.json" 
        
        self.is_grace_period = False
        self.final_warning = False
        self.is_paused = False
        self.blocked_apps = set()
        self.pending_notifications = []
        
        self.stats_tick_counter = 0
        self.current_remaining_sec = self.get_initial_time()
        
        threading.Thread(target=self._process_killer_loop, daemon=True).start()

    def load_std_limits(self):
        if os.path.exists(self.PLIK_LIMITOW):
            try:
                with open(self.PLIK_LIMITOW, "r", encoding="utf-8") as f:
                    content = f.read()
                    import base64
                    decrypted = security.crypt_data(base64.b64decode(content).decode())
                    return json.loads(decrypted)
            except: return {}
        return {}

    def load_calendar_overrides(self):
        if os.path.exists(self.PLIK_KALENDARZA):
            try:
                with open(self.PLIK_KALENDARZA, "r", encoding="utf-8") as f: return json.load(f)
            except: return {}
        return {}

    def get_initial_time(self):
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        if os.path.exists(self.PLIK_STANU):
            try:
                with open(self.PLIK_STANU, "r") as f:
                    data = json.load(f)
                    if data.get("date") == today_str:
                        rem = data.get("remaining_sec", 0)
                        if rem <= 0: return 0
                        return rem
            except: pass

        overrides = self.load_calendar_overrides()
        if today_str in overrides: return int(overrides[today_str]) * 60

        day_idx = datetime.datetime.now().weekday()
        std_limits = self.load_std_limits()
        limit_min = std_limits.get(f"day_{day_idx}", 60)
        return int(limit_min) * 60

    def tick(self):
        if self.is_paused:
            return self.format_time(self.current_remaining_sec)
            
        if self.current_remaining_sec > 0:
            self.current_remaining_sec -= 1
            self.log_stats()
            self.save_state()
            return self.format_time(self.current_remaining_sec)
        else:
            if self.final_warning: return "SHUTDOWN"
            return "EXPIRED"

    def log_stats(self):
        self.stats_tick_counter += 1
        if self.stats_tick_counter >= 60:
            self.stats_tick_counter = 0
            now = datetime.datetime.now()
            today_str = now.strftime('%Y-%m-%d')
            hour_str = str(now.hour)
            
            stats = {}
            if os.path.exists(self.PLIK_STATYSTYK):
                try:
                    with open(self.PLIK_STATYSTYK, "r") as f: stats = json.load(f)
                except: pass
            
            if today_str not in stats:
                stats[today_str] = {"total_min": 0, "hours": {}}
                
            stats[today_str]["total_min"] += 1
            stats[today_str]["hours"][hour_str] = stats[today_str]["hours"].get(hour_str, 0) + 1
            
            with open(self.PLIK_STATYSTYK, "w") as f:
                json.dump(stats, f)

    def save_state(self):
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        data = {"date": today_str, "remaining_sec": self.current_remaining_sec}
        try:
            with open(self.PLIK_STANU, "w") as f: json.dump(data, f)
        except: pass

    def format_time(self, seconds):
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _process_killer_loop(self):
        while True:
            if self.blocked_apps:
                try:
                    for proc in psutil.process_iter(['name']):
                        p_name = proc.info['name']
                        if p_name and p_name.lower() in self.blocked_apps: proc.kill()
                except: pass
            time.sleep(3)

engine = Engine()